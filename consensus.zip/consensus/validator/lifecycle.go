// consensus/validator/lifecycle.go

package validator

import (
	"fmt"
	"math/big"
	"sync"
	"time"

	"github.com/thrylos-labs/go-thrylos/config"
	"github.com/thrylos-labs/go-thrylos/core/state"
	core "github.com/thrylos-labs/go-thrylos/proto/core"
)

// Constants for validator set management
const (
	// 🔴 H-05 FIX: Rate limiting
	MaxValidatorChangePercent = 10.0 // Max 10% change per epoch
	MaxValidatorsPerEpoch     = 100  // Absolute cap per epoch

	// 🔴 H-05 FIX: Unbonding period
	UnbondingPeriodBlocks = 201600 // ~7 days at 3s/block

	// 🔴 H-05 FIX: Epoch system
	DefaultEpochLength = 28800 // ~24 hours at 3s/block

	// 🔴 H-05 FIX: Activation delay
	ActivationDelayEpochs = 2 // Validators activate 2 epochs after registration
)

// LifecycleManager handles validator lifecycle transitions
type LifecycleManager struct {
	config     *config.Config
	worldState *state.WorldState
	manager    *Manager

	// Lifecycle tracking
	lifecycleEvents map[string][]*LifecycleEvent
	transitionQueue chan *LifecycleTransition

	// Performance thresholds
	activationThreshold   float64
	deactivationThreshold float64
	removalThreshold      float64

	// 🔴 H-05 FIX: Epoch-based validator changes
	currentEpoch        int64
	epochLength         int64                        // blocks per epoch
	scheduledValidators map[int64][]*ValidatorChange // epoch -> changes

	// 🔴 H-05 FIX: Rate limiting
	maxValidatorsPerEpoch int
	maxChangePercent      float64

	// 🔴 H-05 FIX: Unbonding system
	unbondingPeriod     int64 // blocks
	unbondingValidators map[string]*UnbondingEntry

	// 🔴 H-05 FIX: Consensus lock protection
	votingInProgress bool
	votingLock       sync.RWMutex

	// Synchronization
	mu sync.RWMutex

	// Lifecycle worker
	isRunning bool
	stopChan  chan struct{}
}

// ValidatorState represents the current state of a validator
type ValidatorState string

const (
	StateRegistered   ValidatorState = "registered"
	StatePending      ValidatorState = "pending"
	StateActive       ValidatorState = "active"
	StateJailed       ValidatorState = "jailed"
	StateSlashed      ValidatorState = "slashed"
	StateDeactivating ValidatorState = "deactivating"
	StateInactive     ValidatorState = "inactive"
	StateRemoving     ValidatorState = "removing"
	StateRemoved      ValidatorState = "removed"
)

// LifecycleEvent represents a validator lifecycle event
type LifecycleEvent struct {
	ValidatorAddress string                 `json:"validator_address"`
	EventType        LifecycleEventType     `json:"event_type"`
	FromState        ValidatorState         `json:"from_state"`
	ToState          ValidatorState         `json:"to_state"`
	Timestamp        int64                  `json:"timestamp"`
	BlockHeight      int64                  `json:"block_height"`
	Reason           string                 `json:"reason"`
	Data             map[string]interface{} `json:"data"`
	TxHash           string                 `json:"tx_hash"`
}

// LifecycleEventType represents types of lifecycle events
type LifecycleEventType string

const (
	EventRegistration      LifecycleEventType = "registration"
	EventActivation        LifecycleEventType = "activation"
	EventDeactivation      LifecycleEventType = "deactivation"
	EventJailing           LifecycleEventType = "jailing"
	EventUnjailing         LifecycleEventType = "unjailing"
	EventSlashing          LifecycleEventType = "slashing"
	EventStakeIncrease     LifecycleEventType = "stake_increase"
	EventStakeDecrease     LifecycleEventType = "stake_decrease"
	EventPerformanceUpdate LifecycleEventType = "performance_update"
	EventRemoval           LifecycleEventType = "removal"
	EventRejoin            LifecycleEventType = "rejoin"
	EventUnbondingComplete LifecycleEventType = "unbonding_complete"
)

// LifecycleTransition represents a pending state transition
type LifecycleTransition struct {
	ValidatorAddress string         `json:"validator_address"`
	TargetState      ValidatorState `json:"target_state"`
	Reason           string         `json:"reason"`
	ScheduledBlock   int64          `json:"scheduled_block"` // CK-04: Block Height
}

// 🔴 H-05 FIX: ValidatorChange tracks scheduled validator set changes
type ValidatorChange struct {
	Address        string          `json:"address"`
	Action         ValidatorAction `json:"action"`
	NewStake       string          `json:"new_stake"`
	ScheduledEpoch int64           `json:"scheduled_epoch"`
}

// 🔴 H-05 FIX: ValidatorAction types
type ValidatorAction string

const (
	ActionAdd         ValidatorAction = "add"
	ActionRemove      ValidatorAction = "remove"
	ActionUpdateStake ValidatorAction = "update_stake"
)

// 🔴 H-05 FIX: UnbondingEntry tracks stake being unbonded
type UnbondingEntry struct {
	ValidatorAddress string `json:"validator_address"`
	Amount           string `json:"amount"`
	CompletionBlock  int64  `json:"completion_block"`
	CreatedAt        int64  `json:"created_at"`
}

// NewLifecycleManager creates a new validator lifecycle manager
func NewLifecycleManager(config *config.Config, worldState *state.WorldState, manager *Manager) *LifecycleManager {
	return &LifecycleManager{
		config:          config,
		worldState:      worldState,
		manager:         manager,
		lifecycleEvents: make(map[string][]*LifecycleEvent),
		transitionQueue: make(chan *LifecycleTransition, 1000),

		// Performance thresholds
		activationThreshold:   0.8,
		deactivationThreshold: 0.3,
		removalThreshold:      0.1,

		// 🔴 H-05 FIX: Initialize epoch system
		currentEpoch:        0,
		epochLength:         DefaultEpochLength,
		scheduledValidators: make(map[int64][]*ValidatorChange),

		// 🔴 H-05 FIX: Initialize rate limiting
		maxValidatorsPerEpoch: MaxValidatorsPerEpoch,
		maxChangePercent:      MaxValidatorChangePercent,

		// 🔴 H-05 FIX: Initialize unbonding system
		unbondingPeriod:     UnbondingPeriodBlocks,
		unbondingValidators: make(map[string]*UnbondingEntry),

		stopChan: make(chan struct{}),
	}
}

// Start begins the lifecycle management process
func (lm *LifecycleManager) Start() error {
	lm.mu.Lock()
	defer lm.mu.Unlock()

	if lm.isRunning {
		return fmt.Errorf("lifecycle manager is already running")
	}

	lm.isRunning = true

	// Calculate current epoch based on block height
	lm.currentEpoch = lm.getCurrentEpoch()

	// Start lifecycle worker
	go lm.lifecycleWorker()

	return nil
}

// Stop halts the lifecycle management process
func (lm *LifecycleManager) Stop() error {
	lm.mu.Lock()
	defer lm.mu.Unlock()

	if !lm.isRunning {
		return fmt.Errorf("lifecycle manager is not running")
	}

	lm.isRunning = false
	close(lm.stopChan)
	return nil
}

// RegisterValidator handles new validator registration
// 🔴 H-05 FIX: Added epoch-based scheduling and stake verification
func (lm *LifecycleManager) RegisterValidator(
	address string,
	pubkey []byte,
	stake string,
	commission float64,
	selfDelegation string,
) error {
	lm.mu.Lock()
	defer lm.mu.Unlock()

	// 1. Validate registration requirements
	if err := lm.validateRegistrationRequirements(address, stake, commission, selfDelegation); err != nil {
		return fmt.Errorf("registration validation failed: %v", err)
	}

	// 🔴 H-05 FIX: Verify stake actually exists in account
	account, err := lm.worldState.GetAccount(address)
	if err != nil {
		return fmt.Errorf("account not found: %v", err)
	}

	accountBalance, _ := new(big.Int).SetString(account.Balance, 10)
	if accountBalance == nil {
		accountBalance = big.NewInt(0)
	}

	requiredStake, _ := new(big.Int).SetString(stake, 10)
	if requiredStake == nil {
		return fmt.Errorf("invalid stake amount")
	}

	if accountBalance.Cmp(requiredStake) < 0 {
		return fmt.Errorf("insufficient account balance for stake: have %s, need %s",
			account.Balance, stake)
	}

	// 🔴 H-05 FIX: Calculate target epoch (not immediate!)
	currentEpoch := lm.getCurrentEpoch()
	targetEpoch := currentEpoch + ActivationDelayEpochs

	// 🔴 H-05 FIX: Check rate limit for target epoch
	if err := lm.checkRateLimit(targetEpoch, ActionAdd); err != nil {
		return fmt.Errorf("rate limit exceeded: %v", err)
	}

	// 2. Register validator (but not active yet!)
	if err := lm.manager.RegisterValidator(address, pubkey, stake, commission); err != nil {
		return fmt.Errorf("validator registration failed: %v", err)
	}

	// Mark as inactive until epoch change
	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("failed to get validator after registration: %v", err)
	}

	validator.Active = false
	if err := lm.worldState.UpdateValidator(validator); err != nil {
		return fmt.Errorf("failed to mark validator inactive: %v", err)
	}

	// 3. 🔴 H-05 FIX: Schedule for future epoch
	lm.scheduleValidatorChange(targetEpoch, &ValidatorChange{
		Address:        address,
		Action:         ActionAdd,
		NewStake:       stake,
		ScheduledEpoch: targetEpoch,
	})

	// 4. Record lifecycle event
	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventRegistration,
		ToState:          StateRegistered,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           fmt.Sprintf("Scheduled for activation at epoch %d", targetEpoch),
		Data: map[string]interface{}{
			"stake":            stake,
			"commission":       commission,
			"target_epoch":     targetEpoch,
			"activation_block": lm.getEpochStartBlock(targetEpoch),
		},
	})

	return nil
}

// ProcessActivation handles validator activation
// 🔴 H-05 FIX: Added consensus lock check
func (lm *LifecycleManager) ProcessActivation(address string) error {
	// 🔴 H-05 FIX: Check consensus lock
	if err := lm.canModifyValidatorSet(); err != nil {
		return err
	}

	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	currentState := lm.getValidatorState(validator)
	if currentState != StateRegistered && currentState != StatePending {
		return fmt.Errorf("validator %s cannot be activated from state %s", address, currentState)
	}

	if err := lm.validateActivationRequirements(validator); err != nil {
		return fmt.Errorf("activation requirements not met: %v", err)
	}

	if err := lm.manager.ActivateValidator(address); err != nil {
		return fmt.Errorf("activation failed: %v", err)
	}

	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventActivation,
		FromState:        currentState,
		ToState:          StateActive,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           "Validator activated",
	})

	return nil
}

// ProcessDeactivation handles validator deactivation
// 🔴 H-05 FIX: Added consensus lock check
func (lm *LifecycleManager) ProcessDeactivation(address string, reason string) error {
	// 🔴 H-05 FIX: Check consensus lock
	if err := lm.canModifyValidatorSet(); err != nil {
		return err
	}

	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	currentState := lm.getValidatorState(validator)

	if err := lm.manager.DeactivateValidator(address, reason); err != nil {
		return fmt.Errorf("deactivation failed: %v", err)
	}

	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventDeactivation,
		FromState:        currentState,
		ToState:          StateInactive,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           reason,
	})

	return nil
}

// ProcessJailing handles validator jailing
// CK-04 FIX: Uses block height instead of time
func (lm *LifecycleManager) ProcessJailing(address string, reason SlashingReason, duration time.Duration) error {
	// Get current validator state
	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	currentState := lm.getValidatorState(validator)

	// CK-04: Calculate Block-Based Jail Duration
	const AvgBlockTime = 3 * time.Second
	blocksToJail := int64(duration / AvgBlockTime)
	if blocksToJail < 1 {
		blocksToJail = 1
	}

	jailUntilBlock := lm.worldState.GetHeight() + blocksToJail

	// Call SlashValidator
	if err := lm.manager.SlashValidator(address, reason, nil); err != nil {
		return fmt.Errorf("slashing failed: %v", err)
	}

	// Update jail time with block height
	validator, err = lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("failed to reload validator after slashing: %v", err)
	}

	validator.JailUntil = jailUntilBlock

	if err := lm.worldState.UpdateValidator(validator); err != nil {
		return fmt.Errorf("failed to update validator jail duration: %v", err)
	}

	// Record event
	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventJailing,
		FromState:        currentState,
		ToState:          StateJailed,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           fmt.Sprintf("Jailed for %s", reason),
		Data: map[string]interface{}{
			"jail_blocks":      blocksToJail,
			"jail_until_block": jailUntilBlock,
			"slashing_reason":  string(reason),
		},
	})

	// Schedule unjailing check
	lm.scheduleTransition(address, StateActive, "Scheduled unjailing", jailUntilBlock)

	return nil
}

// ProcessUnjailing handles validator unjailing
// CK-04 FIX: Uses block height check
func (lm *LifecycleManager) ProcessUnjailing(address string) error {
	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	currentState := lm.getValidatorState(validator)

	// CK-04: Check Block Height
	currentBlock := lm.worldState.GetHeight()
	if validator.JailUntil > currentBlock {
		return fmt.Errorf("validator %s is still jailed until block %d (current: %d)",
			address, validator.JailUntil, currentBlock)
	}

	if err := lm.manager.UnjailValidator(address); err != nil {
		return fmt.Errorf("unjailing failed: %v", err)
	}

	if err := lm.validateActivationRequirements(validator); err == nil {
		lm.manager.ActivateValidator(address)
	}

	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventUnjailing,
		FromState:        currentState,
		ToState:          StateActive,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           "Validator unjailed",
	})

	return nil
}

// ProcessStakeChange handles stake updates
// 🔴 H-05 FIX: Uses unbonding for decreases
func (lm *LifecycleManager) ProcessStakeChange(address string, oldStake, newStake string) error {
	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	currentState := lm.getValidatorState(validator)

	oldStakeBig, _ := new(big.Int).SetString(oldStake, 10)
	newStakeBig, _ := new(big.Int).SetString(newStake, 10)
	minStakeBig, _ := new(big.Int).SetString(lm.config.Staking.MinValidatorStake, 10)

	if oldStakeBig == nil {
		oldStakeBig = big.NewInt(0)
	}
	if newStakeBig == nil {
		newStakeBig = big.NewInt(0)
	}
	if minStakeBig == nil {
		minStakeBig = big.NewInt(0)
	}

	stakeDelta := new(big.Int).Sub(newStakeBig, oldStakeBig)

	var eventType LifecycleEventType
	var reason string

	if stakeDelta.Sign() > 0 {
		// Stake increase - immediate
		eventType = EventStakeIncrease
		reason = fmt.Sprintf("Stake increased by %s", stakeDelta.String())
	} else {
		// 🔴 H-05 FIX: Stake decrease - trigger unbonding
		eventType = EventStakeDecrease
		decreaseAmount := new(big.Int).Neg(stakeDelta)
		reason = fmt.Sprintf("Stake decreased by %s (unbonding)", decreaseAmount.String())

		// Start unbonding process
		if err := lm.ProcessStakeDecrease(address, decreaseAmount.String()); err != nil {
			return fmt.Errorf("failed to process stake decrease: %v", err)
		}
	}

	// Check thresholds
	if newStakeBig.Cmp(minStakeBig) < 0 {
		if currentState == StateActive {
			lm.ProcessDeactivation(address, "Stake below minimum threshold")
		}
	} else {
		if oldStakeBig.Cmp(minStakeBig) < 0 && (currentState == StateInactive || currentState == StateRegistered) {
			lm.scheduleTransition(address, StatePending, "Stake meets minimum threshold", lm.worldState.GetHeight()+1)
		}
	}

	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        eventType,
		FromState:        currentState,
		ToState:          currentState,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           reason,
		Data: map[string]interface{}{
			"old_stake": oldStake,
			"new_stake": newStake,
			"delta":     stakeDelta.String(),
		},
	})

	return nil
}

// 🔴 H-05 FIX: ProcessStakeDecrease handles stake unbonding
func (lm *LifecycleManager) ProcessStakeDecrease(address string, amount string) error {
	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	// Calculate unbonding completion block
	completionBlock := lm.worldState.GetHeight() + lm.unbondingPeriod

	// Create unbonding entry
	unbonding := &UnbondingEntry{
		ValidatorAddress: address,
		Amount:           amount,
		CompletionBlock:  completionBlock,
		CreatedAt:        lm.worldState.GetHeight(),
	}

	// Store unbonding entry
	key := fmt.Sprintf("%s-%d", address, lm.worldState.GetHeight())
	lm.unbondingValidators[key] = unbonding

	// Immediately reduce voting power (but don't release stake yet!)
	stakeBig, _ := new(big.Int).SetString(validator.Stake, 10)
	decreaseBig, _ := new(big.Int).SetString(amount, 10)

	if stakeBig == nil {
		stakeBig = big.NewInt(0)
	}
	if decreaseBig == nil {
		return fmt.Errorf("invalid decrease amount")
	}

	newStake := new(big.Int).Sub(stakeBig, decreaseBig)
	if newStake.Sign() < 0 {
		return fmt.Errorf("cannot decrease stake below zero")
	}

	validator.Stake = newStake.String()

	if err := lm.worldState.UpdateValidator(validator); err != nil {
		return fmt.Errorf("failed to update validator stake: %v", err)
	}

	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventStakeDecrease,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           fmt.Sprintf("Unbonding %s (completes at block %d)", amount, completionBlock),
		Data: map[string]interface{}{
			"amount":           amount,
			"completion_block": completionBlock,
			"unbonding_days":   7,
		},
	})

	return nil
}

// 🔴 H-05 FIX: ProcessCompletedUnbonding processes completed unbonding entries
func (lm *LifecycleManager) ProcessCompletedUnbonding() error {
	lm.mu.Lock()
	defer lm.mu.Unlock()

	currentBlock := lm.worldState.GetHeight()
	completedCount := 0

	for key, unbonding := range lm.unbondingValidators {
		if unbonding.CompletionBlock <= currentBlock {
			// Unbonding complete - return stake to account
			account, err := lm.worldState.GetAccount(unbonding.ValidatorAddress)
			if err != nil {
				fmt.Printf("Warning: failed to get account %s for unbonding completion: %v\n",
					unbonding.ValidatorAddress, err)
				continue
			}

			balanceBig, _ := new(big.Int).SetString(account.Balance, 10)
			unbondingBig, _ := new(big.Int).SetString(unbonding.Amount, 10)

			if balanceBig == nil {
				balanceBig = big.NewInt(0)
			}
			if unbondingBig == nil {
				fmt.Printf("Warning: invalid unbonding amount for %s\n", key)
				continue
			}

			newBalance := new(big.Int).Add(balanceBig, unbondingBig)
			account.Balance = newBalance.String()

			if err := lm.worldState.UpdateAccountWithStorage(account); err != nil {
				fmt.Printf("Warning: failed to update account %s after unbonding: %v\n",
					unbonding.ValidatorAddress, err)
				continue
			}

			// Record event
			lm.recordLifecycleEvent(unbonding.ValidatorAddress, &LifecycleEvent{
				ValidatorAddress: unbonding.ValidatorAddress,
				EventType:        EventUnbondingComplete,
				Timestamp:        time.Now().Unix(),
				BlockHeight:      currentBlock,
				Reason:           fmt.Sprintf("Unbonding of %s completed", unbonding.Amount),
				Data: map[string]interface{}{
					"amount":     unbonding.Amount,
					"started_at": unbonding.CreatedAt,
					"duration":   currentBlock - unbonding.CreatedAt,
				},
			})

			// Remove from unbonding map
			delete(lm.unbondingValidators, key)
			completedCount++
		}
	}

	if completedCount > 0 {
		fmt.Printf("✅ Processed %d completed unbonding entries at block %d\n",
			completedCount, currentBlock)
	}

	return nil
}

// ProcessPerformanceUpdate handles performance-based lifecycle decisions
func (lm *LifecycleManager) ProcessPerformanceUpdate(address string, performanceScore float64) error {
	validator, err := lm.worldState.GetValidator(address)
	if err != nil {
		return fmt.Errorf("validator not found: %v", err)
	}

	currentState := lm.getValidatorState(validator)

	switch currentState {
	case StateActive:
		if performanceScore < lm.deactivationThreshold {
			lm.scheduleTransition(address, StateDeactivating,
				fmt.Sprintf("Poor performance: %.2f", performanceScore),
				lm.worldState.GetHeight()+10)
		}
	case StateInactive, StateRegistered:
		if performanceScore >= lm.activationThreshold {
			lm.scheduleTransition(address, StatePending,
				fmt.Sprintf("Good performance: %.2f", performanceScore),
				lm.worldState.GetHeight()+10)
		}
	}

	lm.recordLifecycleEvent(address, &LifecycleEvent{
		ValidatorAddress: address,
		EventType:        EventPerformanceUpdate,
		FromState:        currentState,
		ToState:          currentState,
		Timestamp:        time.Now().Unix(),
		BlockHeight:      lm.worldState.GetHeight(),
		Reason:           fmt.Sprintf("Performance score updated to %.2f", performanceScore),
		Data:             map[string]interface{}{"performance_score": performanceScore},
	})

	return nil
}

// 🔴 H-05 FIX: checkRateLimit validates rate limits for validator set changes
func (lm *LifecycleManager) checkRateLimit(epoch int64, action ValidatorAction) error {
	// Get scheduled changes for this epoch
	changes := lm.scheduledValidators[epoch]

	// Count adds and removes
	adds := 0
	removes := 0
	for _, change := range changes {
		if change.Action == ActionAdd {
			adds++
		} else if change.Action == ActionRemove {
			removes++
		}
	}

	// 1. Check absolute limit
	if action == ActionAdd && adds >= lm.maxValidatorsPerEpoch {
		return fmt.Errorf("maximum validator additions (%d) reached for epoch %d",
			lm.maxValidatorsPerEpoch, epoch)
	}

	// 2. Check percentage limit
	currentValidators := len(lm.worldState.GetActiveValidators())
	if currentValidators == 0 {
		// Bootstrap case - allow initial validators
		return nil
	}

	netChange := adds - removes
	if action == ActionAdd {
		netChange++ // Include this new add
	} else if action == ActionRemove {
		netChange-- // Include this new remove
	}

	// Calculate absolute change percentage
	absChange := netChange
	if absChange < 0 {
		absChange = -absChange
	}

	changePercent := (float64(absChange) / float64(currentValidators)) * 100
	if changePercent > lm.maxChangePercent {
		return fmt.Errorf("validator set change of %.2f%% exceeds maximum %.2f%%",
			changePercent, lm.maxChangePercent)
	}

	return nil
}

// 🔴 H-05 FIX: scheduleValidatorChange schedules a validator set change for a future epoch
func (lm *LifecycleManager) scheduleValidatorChange(epoch int64, change *ValidatorChange) {
	if lm.scheduledValidators[epoch] == nil {
		lm.scheduledValidators[epoch] = make([]*ValidatorChange, 0)
	}
	lm.scheduledValidators[epoch] = append(lm.scheduledValidators[epoch], change)

	fmt.Printf("📅 Scheduled validator %s for %s at epoch %d (block %d)\n",
		change.Address, change.Action, epoch, lm.getEpochStartBlock(epoch))
}

// 🔴 H-05 FIX: ProcessEpochTransition processes validator changes at epoch boundary
func (lm *LifecycleManager) ProcessEpochTransition() error {
	lm.mu.Lock()
	defer lm.mu.Unlock()

	currentEpoch := lm.getCurrentEpoch()

	// Get scheduled changes for this epoch
	changes := lm.scheduledValidators[currentEpoch]
	if len(changes) == 0 {
		return nil
	}

	fmt.Printf("⚡ Processing %d validator changes for epoch %d\n", len(changes), currentEpoch)

	// Apply all changes atomically
	successCount := 0
	for _, change := range changes {
		var err error
		switch change.Action {
		case ActionAdd:
			err = lm.ProcessActivation(change.Address)
		case ActionRemove:
			err = lm.ProcessDeactivation(change.Address, "Scheduled removal")
		case ActionUpdateStake:
			// Handle stake updates
			validator, getErr := lm.worldState.GetValidator(change.Address)
			if getErr == nil {
				err = lm.ProcessStakeChange(change.Address, validator.Stake, change.NewStake)
			} else {
				err = getErr
			}
		}

		if err != nil {
			fmt.Printf("⚠️  Failed to apply change for %s: %v\n", change.Address, err)
		} else {
			successCount++
		}
	}

	fmt.Printf("✅ Successfully applied %d/%d validator changes for epoch %d\n",
		successCount, len(changes), currentEpoch)

	// Clean up processed changes
	delete(lm.scheduledValidators, currentEpoch)

	return nil
}

// 🔴 H-05 FIX: BeginVoting locks the validator set during voting
func (lm *LifecycleManager) BeginVoting() error {
	lm.votingLock.Lock()
	defer lm.votingLock.Unlock()

	if lm.votingInProgress {
		return fmt.Errorf("voting already in progress")
	}

	lm.votingInProgress = true
	return nil
}

// 🔴 H-05 FIX: EndVoting unlocks the validator set after voting
func (lm *LifecycleManager) EndVoting() error {
	lm.votingLock.Lock()
	defer lm.votingLock.Unlock()

	lm.votingInProgress = false
	return nil
}

// 🔴 H-05 FIX: canModifyValidatorSet checks if validator set can be modified
func (lm *LifecycleManager) canModifyValidatorSet() error {
	lm.votingLock.RLock()
	defer lm.votingLock.RUnlock()

	if lm.votingInProgress {
		return fmt.Errorf("cannot modify validator set during voting")
	}

	return nil
}

// 🔴 H-05 FIX: getCurrentEpoch calculates current epoch from block height
func (lm *LifecycleManager) getCurrentEpoch() int64 {
	return lm.worldState.GetHeight() / lm.epochLength
}

// 🔴 H-05 FIX: getEpochStartBlock calculates the first block of an epoch
func (lm *LifecycleManager) getEpochStartBlock(epoch int64) int64 {
	return epoch * lm.epochLength
}

// getValidatorState determines the current state of a validator
// CK-04 FIX: Uses block height check
func (lm *LifecycleManager) getValidatorState(validator *core.Validator) ValidatorState {
	currentBlock := lm.worldState.GetHeight()

	// CK-04: Block Height check
	if validator.JailUntil > currentBlock {
		return StateJailed
	}

	if validator.Active {
		return StateActive
	}

	if validator.Stake < lm.config.Staking.MinValidatorStake {
		return StateInactive
	}

	return StateRegistered
}

// validateRegistrationRequirements validates requirements for validator registration
func (lm *LifecycleManager) validateRegistrationRequirements(address string, stake string, commission float64, selfDelegation string) error {
	if commission < 0 || commission > 100 {
		return fmt.Errorf("commission must be between 0 and 100")
	}

	stakeBig, ok := new(big.Int).SetString(stake, 10)
	if !ok {
		return fmt.Errorf("invalid stake amount")
	}

	selfDelegationBig, ok := new(big.Int).SetString(selfDelegation, 10)
	if !ok {
		return fmt.Errorf("invalid self-delegation amount")
	}

	minStakeBig, _ := new(big.Int).SetString(lm.config.Staking.MinValidatorStake, 10)
	if minStakeBig == nil {
		minStakeBig = big.NewInt(0)
	}

	if stakeBig.Cmp(minStakeBig) < 0 {
		return fmt.Errorf("stake %s below minimum %s", stake, lm.config.Staking.MinValidatorStake)
	}

	if selfDelegationBig.Sign() <= 0 {
		return fmt.Errorf("self-delegation must be positive")
	}

	if selfDelegationBig.Cmp(stakeBig) > 0 {
		return fmt.Errorf("self-delegation cannot exceed total stake")
	}

	return nil
}

// validateActivationRequirements validates requirements for validator activation
// CK-04 FIX: Uses block height check
func (lm *LifecycleManager) validateActivationRequirements(validator *core.Validator) error {
	if validator.Stake < lm.config.Staking.MinValidatorStake {
		return fmt.Errorf("stake below minimum")
	}

	if validator.SelfStake < lm.config.Staking.MinSelfStake {
		return fmt.Errorf("self-stake below minimum")
	}

	// CK-04: Block check
	if validator.JailUntil > lm.worldState.GetHeight() {
		return fmt.Errorf("validator is jailed until block %d", validator.JailUntil)
	}

	return nil
}

// scheduleTransition schedules a state transition at a specific BLOCK
// CK-04 FIX: Uses block height
func (lm *LifecycleManager) scheduleTransition(address string, targetState ValidatorState, reason string, scheduledBlock int64) {
	if scheduledBlock == 0 {
		scheduledBlock = lm.worldState.GetHeight() + 1
	}

	transition := &LifecycleTransition{
		ValidatorAddress: address,
		TargetState:      targetState,
		Reason:           reason,
		ScheduledBlock:   scheduledBlock,
	}

	select {
	case lm.transitionQueue <- transition:
	default:
		fmt.Printf("⚠️  Transition queue full, dropping transition for %s\n", address)
	}
}

// recordLifecycleEvent records a lifecycle event
func (lm *LifecycleManager) recordLifecycleEvent(address string, event *LifecycleEvent) {
	if lm.lifecycleEvents[address] == nil {
		lm.lifecycleEvents[address] = make([]*LifecycleEvent, 0)
	}
	lm.lifecycleEvents[address] = append(lm.lifecycleEvents[address], event)

	// Keep only last 100 events
	if len(lm.lifecycleEvents[address]) > 100 {
		lm.lifecycleEvents[address] = lm.lifecycleEvents[address][1:]
	}
}

// lifecycleWorker processes scheduled transitions
// 🔴 H-05 FIX: Also processes epoch transitions and unbonding
func (lm *LifecycleManager) lifecycleWorker() {
	ticker := time.NewTicker(3 * time.Second) // Check every block (~3s)
	defer ticker.Stop()

	for {
		select {
		case <-lm.stopChan:
			return
		case transition := <-lm.transitionQueue:
			lm.processScheduledTransition(transition)
		case <-ticker.C:
			lm.performPeriodicChecks()
		}
	}
}

// processScheduledTransition processes a scheduled state transition
// CK-04 FIX: Uses block height check
func (lm *LifecycleManager) processScheduledTransition(transition *LifecycleTransition) {
	currentBlock := lm.worldState.GetHeight()

	// CK-04: Wait for Block Height
	if transition.ScheduledBlock > currentBlock {
		// Not time yet, requeue
		go func() {
			time.Sleep(1 * time.Second)
			select {
			case lm.transitionQueue <- transition:
			default:
				fmt.Printf("⚠️  Failed to requeue transition for %s\n", transition.ValidatorAddress)
			}
		}()
		return
	}

	switch transition.TargetState {
	case StatePending:
		validator, err := lm.worldState.GetValidator(transition.ValidatorAddress)
		if err == nil && lm.validateActivationRequirements(validator) == nil {
			lm.ProcessActivation(transition.ValidatorAddress)
		}
	case StateActive:
		lm.ProcessUnjailing(transition.ValidatorAddress)
	case StateDeactivating:
		lm.ProcessDeactivation(transition.ValidatorAddress, transition.Reason)
	}
}

// performPeriodicChecks performs various periodic lifecycle checks
// 🔴 H-05 FIX: Added epoch transition and unbonding checks
func (lm *LifecycleManager) performPeriodicChecks() {
	lm.mu.Lock()
	currentBlock := lm.worldState.GetHeight()
	currentEpoch := lm.getCurrentEpoch()

	// Check if we've entered a new epoch
	if currentEpoch > lm.currentEpoch {
		lm.mu.Unlock() // Release lock before epoch transition
		lm.ProcessEpochTransition()
		lm.mu.Lock()
		lm.currentEpoch = currentEpoch
	}
	lm.mu.Unlock()

	// Process completed unbonding entries
	lm.ProcessCompletedUnbonding()

	// Check for automatic unjailing
	lm.mu.Lock()
	defer lm.mu.Unlock()

	activeValidators := lm.worldState.GetActiveValidators()
	for _, validator := range activeValidators {
		// CK-04: Block height check
		if validator.JailUntil > 0 && validator.JailUntil <= currentBlock {
			lm.ProcessUnjailing(validator.Address)
		}
	}
}

// GetLifecycleEvents returns lifecycle events for a validator
func (lm *LifecycleManager) GetLifecycleEvents(address string) ([]*LifecycleEvent, error) {
	lm.mu.RLock()
	defer lm.mu.RUnlock()

	events, exists := lm.lifecycleEvents[address]
	if !exists {
		return []*LifecycleEvent{}, nil
	}

	eventsCopy := make([]*LifecycleEvent, len(events))
	copy(eventsCopy, events)
	return eventsCopy, nil
}

// 🔴 H-05 FIX: GetUnbondingEntries returns all unbonding entries for a validator
func (lm *LifecycleManager) GetUnbondingEntries(address string) ([]*UnbondingEntry, error) {
	lm.mu.RLock()
	defer lm.mu.RUnlock()

	var entries []*UnbondingEntry
	for _, unbonding := range lm.unbondingValidators {
		if unbonding.ValidatorAddress == address {
			entries = append(entries, unbonding)
		}
	}

	return entries, nil
}

// 🔴 H-05 FIX: GetScheduledChanges returns scheduled validator changes for an epoch
func (lm *LifecycleManager) GetScheduledChanges(epoch int64) ([]*ValidatorChange, error) {
	lm.mu.RLock()
	defer lm.mu.RUnlock()

	changes := lm.scheduledValidators[epoch]
	if changes == nil {
		return []*ValidatorChange{}, nil
	}

	changesCopy := make([]*ValidatorChange, len(changes))
	copy(changesCopy, changes)
	return changesCopy, nil
}
