// core/transaction/pool.go
package transaction

import (
	"fmt"
	"log"
	"sort"
	"sync"
	"time"

	"github.com/thrylos-labs/go-thrylos/config" // Import config
	"github.com/thrylos-labs/go-thrylos/core/account"
	"github.com/thrylos-labs/go-thrylos/proto/core"
)

// TransactionEntry wraps a transaction with metadata
type TransactionEntry struct {
	Transaction *core.Transaction
	ReceivedAt  time.Time
}

// Pool manages pending transactions for a shard
type Pool struct {
	// Transaction storage
	// CHANGED: pending now maps to TransactionEntry instead of raw Transaction
	pending   map[string]*TransactionEntry            // txid -> entry
	byAddress map[string]map[uint64]*core.Transaction // address -> nonce -> tx
	byHash    map[string]*core.Transaction            // hash -> tx for quick lookup

	// Dependencies
	accountManager *account.AccountManager

	// Configuration
	shardID     account.ShardID
	totalShards int
	maxTxs      int
	minGasPrice int64

	// Statistics
	totalAdded   int64
	totalRemoved int64

	// Synchronization
	mu sync.RWMutex
}

// PoolStats represents statistics about the transaction pool
type PoolStats struct {
	PendingCount int   `json:"pending_count"`
	AddressCount int   `json:"address_count"`
	TotalAdded   int64 `json:"total_added"`
	TotalRemoved int64 `json:"total_removed"`
	ShardID      int   `json:"shard_id"`
	MaxCapacity  int   `json:"max_capacity"`
	MinGasPrice  int64 `json:"min_gas_price"`
}

// NewPool creates a new transaction pool for a shard
func NewPool(shardID account.ShardID, totalShards int, maxTxs int, minGasPrice int64, am *account.AccountManager) *Pool {
	return &Pool{
		pending:        make(map[string]*TransactionEntry), // Updated type
		byAddress:      make(map[string]map[uint64]*core.Transaction),
		byHash:         make(map[string]*core.Transaction),
		accountManager: am,
		shardID:        shardID,
		totalShards:    totalShards,
		maxTxs:         maxTxs,
		minGasPrice:    minGasPrice,
	}
}

// AddTransaction adds a transaction to the pool after validation
func (p *Pool) AddTransaction(tx *core.Transaction) error {
	if err := p.validateTransactionForPool(tx); err != nil {
		return fmt.Errorf("transaction validation failed: %v", err)
	}

	p.mu.Lock()
	defer p.mu.Unlock()

	// 1. Check if transaction already exists
	if _, exists := p.pending[tx.Id]; exists {
		return fmt.Errorf("transaction %s already exists in pool", tx.Id)
	}
	if _, exists := p.byHash[tx.Hash]; exists {
		return fmt.Errorf("transaction with hash %s already exists in pool", tx.Hash)
	}

	// 2. Initialize sender map if needed
	senderTxs, exists := p.byAddress[tx.From]
	if !exists {
		senderTxs = make(map[uint64]*core.Transaction)
		p.byAddress[tx.From] = senderTxs
	}

	// 3. Check for Duplicate Nonce (Replace-by-Fee logic)
	if existingTx, conflict := senderTxs[tx.Nonce]; conflict {
		if tx.GasPrice <= existingTx.GasPrice {
			return fmt.Errorf("nonce %d already exists; replacement requires higher gas price", tx.Nonce)
		}
		// Remove old transaction internally
		p.removeInternal(existingTx)
	}

	// 4. Validate Total Pending Balance
	if err := p.validateTotalPendingBalance(tx.From, tx); err != nil {
		return fmt.Errorf("insufficient balance for pending transactions: %v", err)
	}

	// 5. Check Capacity
	if len(p.pending) >= p.maxTxs {
		if !p.evictLowestGasPrice(tx.GasPrice) {
			return fmt.Errorf("transaction pool is full")
		}
	}

	// 6. Add to all indices
	// CHANGED: Wrap transaction in TransactionEntry
	p.pending[tx.Id] = &TransactionEntry{
		Transaction: tx,
		ReceivedAt:  time.Now(),
	}
	p.byHash[tx.Hash] = tx

	if p.byAddress[tx.From] == nil {
		p.byAddress[tx.From] = make(map[uint64]*core.Transaction)
	}
	p.byAddress[tx.From][tx.Nonce] = tx

	p.totalAdded++
	return nil
}

// CleanupExpired removes transactions that have been in the pool longer than the TTL
// Fixes: MEDIUM Severity - Missing Transaction Expiration
func (p *Pool) CleanupExpired() {
	p.mu.Lock()
	defer p.mu.Unlock()

	now := time.Now()
	expiredCount := 0

	// Iterate over pending transactions
	for _, entry := range p.pending {
		if now.Sub(entry.ReceivedAt) > config.TransactionPoolTTL {
			// We use removeInternal to ensure indices (byHash, byAddress) are also cleared
			p.removeInternal(entry.Transaction)
			expiredCount++
			log.Printf("Removed expired transaction: %s (Age: %v)",
				entry.Transaction.Id, now.Sub(entry.ReceivedAt))
		}
	}

	if expiredCount > 0 {
		log.Printf("CleanupExpired: Removed %d stale transactions", expiredCount)
	}
}

// validateTotalPendingBalance calculates the total cost of pending transactions
func (p *Pool) validateTotalPendingBalance(address string, newTx *core.Transaction) error {
	if p.accountManager == nil {
		return nil
	}

	account, err := p.accountManager.GetAccount(address)
	if err != nil {
		return fmt.Errorf("could not retrieve account: %v", err)
	}

	totalRequired := int64(0)

	if senderTxs, exists := p.byAddress[address]; exists {
		for _, tx := range senderTxs {
			if tx.Nonce == newTx.Nonce {
				continue
			}
			totalRequired += tx.Amount + (tx.Gas * tx.GasPrice)
		}
	}

	totalRequired += newTx.Amount + (newTx.Gas * newTx.GasPrice)

	if account.Balance < totalRequired {
		return fmt.Errorf("have %d, need %d", account.Balance, totalRequired)
	}

	return nil
}

// removeInternal performs the deletion logic without locking
func (p *Pool) removeInternal(tx *core.Transaction) {
	delete(p.pending, tx.Id)
	delete(p.byHash, tx.Hash)

	if senderTxs, exists := p.byAddress[tx.From]; exists {
		delete(senderTxs, tx.Nonce)
		if len(senderTxs) == 0 {
			delete(p.byAddress, tx.From)
		}
	}
	p.totalRemoved++
}

// RemoveTransaction removes a transaction from the pool
func (p *Pool) RemoveTransaction(txID string) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	entry, exists := p.pending[txID]
	if !exists {
		return fmt.Errorf("transaction %s not found in pool", txID)
	}

	p.removeInternal(entry.Transaction)
	return nil
}

// RemoveTransactionByHash removes a transaction by its hash
func (p *Pool) RemoveTransactionByHash(txHash string) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	tx, exists := p.byHash[txHash]
	if !exists {
		return fmt.Errorf("transaction with hash %s not found in pool", txHash)
	}

	p.removeInternal(tx)
	return nil
}

// GetTransaction retrieves a transaction by ID
func (p *Pool) GetTransaction(txID string) (*core.Transaction, error) {
	p.mu.RLock()
	defer p.mu.RUnlock()

	entry, exists := p.pending[txID]
	if !exists {
		return nil, fmt.Errorf("transaction %s not found in pool", txID)
	}

	return entry.Transaction, nil
}

// GetTransactionByHash retrieves a transaction by hash
func (p *Pool) GetTransactionByHash(txHash string) (*core.Transaction, error) {
	p.mu.RLock()
	defer p.mu.RUnlock()

	tx, exists := p.byHash[txHash]
	if !exists {
		return nil, fmt.Errorf("transaction with hash %s not found in pool", txHash)
	}

	return tx, nil
}

// GetPendingTransactions returns all pending transactions
func (p *Pool) GetPendingTransactions() []*core.Transaction {
	p.mu.RLock()
	defer p.mu.RUnlock()

	txs := make([]*core.Transaction, 0, len(p.pending))
	for _, entry := range p.pending {
		txs = append(txs, entry.Transaction)
	}

	return txs
}

// getSortedTransactions is a helper to get transactions for an address sorted by nonce
func (p *Pool) getSortedTransactions(address string) []*core.Transaction {
	senderMap, exists := p.byAddress[address]
	if !exists {
		return []*core.Transaction{}
	}

	result := make([]*core.Transaction, 0, len(senderMap))
	for _, tx := range senderMap {
		result = append(result, tx)
	}

	sort.Slice(result, func(i, j int) bool {
		return result[i].Nonce < result[j].Nonce
	})

	return result
}

// GetTransactionsForAddress returns all transactions for a specific address
func (p *Pool) GetTransactionsForAddress(address string) []*core.Transaction {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.getSortedTransactions(address)
}

// GetExecutableTransactions returns transactions ready for execution
func (p *Pool) GetExecutableTransactions(maxCount int, accountManager *account.AccountManager) []*core.Transaction {
	p.mu.RLock()
	defer p.mu.RUnlock()

	am := accountManager
	if am == nil {
		am = p.accountManager
	}

	var executable []*core.Transaction
	processed := make(map[string]bool)

	// First pass: Perfect nonce sequence
	for address := range p.byAddress {
		if len(executable) >= maxCount {
			break
		}

		txs := p.getSortedTransactions(address)
		if len(txs) == 0 {
			continue
		}

		currentNonce, err := am.GetNonce(address)
		if err != nil {
			continue
		}

		account, err := am.GetAccount(address)
		if err != nil {
			continue
		}

		expectedNonce := currentNonce
		remainingBalance := account.Balance

		for _, tx := range txs {
			if len(executable) >= maxCount {
				break
			}

			if tx.Nonce == expectedNonce {
				totalCost := tx.Amount + (tx.Gas * tx.GasPrice)
				if remainingBalance >= totalCost {
					executable = append(executable, tx)
					expectedNonce++
					remainingBalance -= totalCost
				} else {
					break
				}
			} else if tx.Nonce > expectedNonce {
				break
			}
		}
		processed[address] = true
	}

	// Second pass: Fill with high gas price txs if room
	if len(executable) < maxCount && len(executable) < len(p.pending)/2 {
		var remaining []*core.Transaction

		for _, entry := range p.pending {
			isIncluded := false
			for _, execTx := range executable {
				if execTx.Id == entry.Transaction.Id {
					isIncluded = true
					break
				}
			}
			if !isIncluded {
				remaining = append(remaining, entry.Transaction)
			}
		}

		sort.Slice(remaining, func(i, j int) bool {
			return remaining[i].GasPrice > remaining[j].GasPrice
		})

		for _, tx := range remaining {
			if len(executable) >= maxCount {
				break
			}

			currentNonce, err := am.GetNonce(tx.From)
			if err != nil {
				continue
			}

			account, err := am.GetAccount(tx.From)
			if err != nil {
				continue
			}

			if tx.Nonce >= currentNonce && tx.Nonce <= currentNonce+5 {
				totalCost := tx.Amount + (tx.Gas * tx.GasPrice)
				if account.Balance >= totalCost {
					executable = append(executable, tx)
				}
			}
		}
	}

	return executable
}

// GetHighestGasPriceTransactions returns transactions with highest gas prices
func (p *Pool) GetHighestGasPriceTransactions(maxCount int) []*core.Transaction {
	p.mu.RLock()
	defer p.mu.RUnlock()

	txs := make([]*core.Transaction, 0, len(p.pending))
	for _, entry := range p.pending {
		txs = append(txs, entry.Transaction)
	}

	sort.Slice(txs, func(i, j int) bool {
		return txs[i].GasPrice > txs[j].GasPrice
	})

	if len(txs) > maxCount {
		txs = txs[:maxCount]
	}

	return txs
}

// GetStats returns statistics about the transaction pool
func (p *Pool) GetStats() *PoolStats {
	p.mu.RLock()
	defer p.mu.RUnlock()

	return &PoolStats{
		PendingCount: len(p.pending),
		AddressCount: len(p.byAddress),
		TotalAdded:   p.totalAdded,
		TotalRemoved: p.totalRemoved,
		ShardID:      int(p.shardID),
		MaxCapacity:  p.maxTxs,
		MinGasPrice:  p.minGasPrice,
	}
}

// Clear removes all transactions from the pool
func (p *Pool) Clear() {
	p.mu.Lock()
	defer p.mu.Unlock()

	p.totalRemoved += int64(len(p.pending))

	p.pending = make(map[string]*TransactionEntry)
	p.byAddress = make(map[string]map[uint64]*core.Transaction)
	p.byHash = make(map[string]*core.Transaction)
}

// CleanupStaleTransactions removes transactions older than the specified duration (based on Timestamp)
func (p *Pool) CleanupStaleTransactions(maxAge time.Duration) int {
	p.mu.Lock()
	defer p.mu.Unlock()

	currentTime := time.Now().Unix()
	removed := 0

	var staleTransactions []*core.Transaction

	for _, entry := range p.pending {
		// This checks the signed timestamp (when user created it)
		if currentTime-entry.Transaction.Timestamp > int64(maxAge.Seconds()) {
			staleTransactions = append(staleTransactions, entry.Transaction)
		}
	}

	for _, tx := range staleTransactions {
		p.removeInternal(tx)
		removed++
	}

	return removed
}

// validateTransactionForPool validates a transaction for pool inclusion
func (p *Pool) validateTransactionForPool(tx *core.Transaction) error {
	if tx == nil {
		return fmt.Errorf("transaction cannot be nil")
	}
	if tx.Id == "" {
		return fmt.Errorf("transaction ID cannot be empty")
	}
	if tx.Hash == "" {
		return fmt.Errorf("transaction hash cannot be empty")
	}
	if tx.From == "" {
		return fmt.Errorf("sender address cannot be empty")
	}
	if tx.Amount < 0 {
		return fmt.Errorf("transaction amount cannot be negative")
	}
	if tx.Gas <= 0 {
		return fmt.Errorf("gas must be positive")
	}
	if tx.GasPrice < p.minGasPrice {
		return fmt.Errorf("gas price %d below minimum %d", tx.GasPrice, p.minGasPrice)
	}
	if len(tx.Signature) == 0 {
		return fmt.Errorf("transaction signature cannot be empty")
	}

	if p.shardID != account.BeaconShardID {
		senderShard := account.CalculateShardID(tx.From, p.totalShards)
		if senderShard != p.shardID {
			return fmt.Errorf("transaction sender %s belongs to shard %d, not %d",
				tx.From, senderShard, p.shardID)
		}
	}

	return nil
}

// evictLowestGasPrice tries to evict the transaction with lowest gas price
func (p *Pool) evictLowestGasPrice(newGasPrice int64) bool {
	var lowestGasPrice int64 = newGasPrice
	var evictTx *core.Transaction

	for _, entry := range p.pending {
		if entry.Transaction.GasPrice < lowestGasPrice {
			lowestGasPrice = entry.Transaction.GasPrice
			evictTx = entry.Transaction
		}
	}

	if evictTx != nil {
		p.removeInternal(evictTx)
		return true
	}

	return false
}

// GetNextNonce returns the next expected nonce for an address
func (p *Pool) GetNextNonce(address string, currentNonce uint64) uint64 {
	p.mu.RLock()
	defer p.mu.RUnlock()

	senderTxs, exists := p.byAddress[address]
	if !exists {
		return currentNonce
	}

	highestNonce := currentNonce - 1
	for nonce := range senderTxs {
		if nonce > highestNonce {
			highestNonce = nonce
		}
	}

	return highestNonce + 1
}

// HasTransaction checks if a transaction exists in the pool
func (p *Pool) HasTransaction(txID string) bool {
	p.mu.RLock()
	defer p.mu.RUnlock()
	_, exists := p.pending[txID]
	return exists
}

// HasTransactionHash checks if a transaction with the given hash exists
func (p *Pool) HasTransactionHash(txHash string) bool {
	p.mu.RLock()
	defer p.mu.RUnlock()
	_, exists := p.byHash[txHash]
	return exists
}

// GetPoolCapacity returns current capacity information
func (p *Pool) GetPoolCapacity() (current int, max int, available int) {
	p.mu.RLock()
	defer p.mu.RUnlock()
	current = len(p.pending)
	max = p.maxTxs
	available = max - current
	if available < 0 {
		available = 0
	}
	return current, max, available
}

// UpdateGasPrice updates the minimum gas price for the pool
func (p *Pool) UpdateGasPrice(newMinGasPrice int64) int {
	p.mu.Lock()
	defer p.mu.Unlock()

	p.minGasPrice = newMinGasPrice

	var toRemove []*core.Transaction
	for _, entry := range p.pending {
		if entry.Transaction.GasPrice < newMinGasPrice {
			toRemove = append(toRemove, entry.Transaction)
		}
	}

	for _, tx := range toRemove {
		p.removeInternal(tx)
	}

	return len(toRemove)
}

// GetTransactionsByGasPrice returns transactions sorted by gas price
func (p *Pool) GetTransactionsByGasPrice(ascending bool) []*core.Transaction {
	p.mu.RLock()
	defer p.mu.RUnlock()

	txs := make([]*core.Transaction, 0, len(p.pending))
	for _, entry := range p.pending {
		txs = append(txs, entry.Transaction)
	}

	sort.Slice(txs, func(i, j int) bool {
		if ascending {
			return txs[i].GasPrice < txs[j].GasPrice
		}
		return txs[i].GasPrice > txs[j].GasPrice
	})

	return txs
}

// GetAddressNonceGap returns the nonce gap for an address
func (p *Pool) GetAddressNonceGap(address string, currentNonce uint64) []uint64 {
	p.mu.RLock()
	defer p.mu.RUnlock()

	senderTxs, exists := p.byAddress[address]
	if !exists {
		return []uint64{}
	}

	var highestNonce uint64 = currentNonce - 1
	for nonce := range senderTxs {
		if nonce > highestNonce {
			highestNonce = nonce
		}
	}

	var gaps []uint64
	for nonce := currentNonce; nonce <= highestNonce; nonce++ {
		if _, ok := senderTxs[nonce]; !ok {
			gaps = append(gaps, nonce)
		}
	}

	return gaps
}
