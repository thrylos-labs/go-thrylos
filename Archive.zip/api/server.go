// api/server.go

// Main HTTPS REST API server for blockchain data access

// Provides clean REST endpoints for wallets and applications to query blockchain state
// Handles account balances, transactions, blocks, validators, and system status
// Uses Gorilla Mux for routing, includes CORS support and logging middleware
// Designed for HTTPS polling approach - simple, reliable, cacheable endpoints
// Serves as the primary interface between external applications and your blockchain node

// Updated for account-based system with staking support

package api

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"sort"
	"strconv"
	"time"

	"github.com/gorilla/mux"
	"github.com/rs/cors"
	"github.com/thrylos-labs/go-thrylos/config"
	"github.com/thrylos-labs/go-thrylos/core/state"
	"github.com/thrylos-labs/go-thrylos/proto/core"
)

// Server represents the HTTP API server
type Server struct {
	worldState *state.WorldState
	router     *mux.Router
	server     *http.Server
	port       int

	// HTTPS configuration
	enableTLS bool
	certFile  string
	keyFile   string

	// Rate limiting
	rateLimiter     *RateLimiter
	rateLimitConfig *RateLimitConfig
}

// ServerConfig represents server configuration
type ServerConfig struct {
	Port      int
	EnableTLS bool
	CertFile  string
	KeyFile   string
}

// Response structures for account-based system
type AccountResponse struct {
	Address      string           `json:"address"`
	Balance      int64            `json:"balance"`
	Nonce        uint64           `json:"nonce"`
	StakedAmount int64            `json:"staked_amount"`
	Rewards      int64            `json:"rewards"`
	DelegatedTo  map[string]int64 `json:"delegated_to"`
}

type DelegationsResponse struct {
	Address     string           `json:"address"`
	Delegations map[string]int64 `json:"delegations"`
	Count       int              `json:"count"`
}

type TransactionResponse struct {
	Hash      string `json:"hash"`
	From      string `json:"from"`
	To        string `json:"to"`
	Amount    int64  `json:"amount"`
	Nonce     uint64 `json:"nonce"`
	Gas       int64  `json:"gas"`
	GasPrice  int64  `json:"gas_price"`
	Timestamp int64  `json:"timestamp"`
	Status    string `json:"status"`
	Signature string `json:"signature,omitempty"`
}

type TransactionHistoryResponse struct {
	Address      string                `json:"address"`
	Transactions []TransactionResponse `json:"transactions"`
	Count        int                   `json:"count"`
	Limit        int                   `json:"limit"`
}

// NewServer creates a new API server
func NewServer(worldState *state.WorldState, port int) *Server {
	server := &Server{
		worldState:      worldState,
		port:            port,
		rateLimitConfig: DefaultRateLimitConfig(),
	}

	server.rateLimiter = NewRateLimiter(server.rateLimitConfig)
	server.setupRoutes()
	return server
}

func NewServerWithServerConfig(worldState *state.WorldState, serverConfig *ServerConfig) *Server {
	server := &Server{
		worldState:      worldState,
		port:            serverConfig.Port,
		enableTLS:       serverConfig.EnableTLS,
		certFile:        serverConfig.CertFile,
		keyFile:         serverConfig.KeyFile,
		rateLimitConfig: DefaultRateLimitConfig(),
	}

	server.rateLimiter = NewRateLimiter(server.rateLimitConfig)
	server.setupRoutes()
	return server
}

func NewServerWithConfig(worldState *state.WorldState, cfg *config.Config) *Server {
	// Create rate limit config from main config
	rateLimitConfig := &RateLimitConfig{
		StrictRPS:       float64(cfg.API.RateLimit) / 10, // 1/10 of standard for strict
		StandardRPS:     float64(cfg.API.RateLimit),
		PermissiveRPS:   float64(cfg.API.RateLimit) * 10, // 10x for permissive
		StrictBurst:     3,
		StandardBurst:   20,
		PermissiveBurst: 200,
		CleanupInterval: 1 * time.Minute,
		MaxIdleTime:     5 * time.Minute,
		Enabled:         true,
	}

	server := &Server{
		worldState:      worldState,
		port:            extractPortFromConfig(cfg.API.RESTAddr),
		enableTLS:       cfg.API.EnableTLS,
		certFile:        cfg.API.CertFile,
		keyFile:         cfg.API.KeyFile,
		rateLimitConfig: rateLimitConfig,
	}

	server.rateLimiter = NewRateLimiter(server.rateLimitConfig)
	server.setupRoutes()
	return server
}

// Helper to extract port from config address
func extractPortFromConfig(addr string) int {
	switch addr {
	case ":8080":
		return 8080
	case ":8443":
		return 8443
	default:
		return 8080
	}
}

// NewServerWithConfig creates a new API server with full configuration
// func NewServerWithConfig(worldState *state.WorldState, config *ServerConfig) *Server {
// 	server := &Server{
// 		worldState: worldState,
// 		port:       config.Port,
// 		enableTLS:  config.EnableTLS,
// 		certFile:   config.CertFile,
// 		keyFile:    config.KeyFile,
// 	}

// 	server.setupRoutes()
// 	return server
// }

// setupRoutes configures all API routes
// setupRoutes configures all API routes
func (s *Server) setupRoutes() {
	s.router = mux.NewRouter()

	// API version prefix
	api := s.router.PathPrefix("/api/v1").Subrouter()

	// ========== STRICT RATE LIMITING (1 req/sec) ==========
	strict := api.PathPrefix("").Subrouter()
	strict.Use(s.RateLimitMiddleware("strict"))
	strict.HandleFunc("/fund", s.fundAddress).Methods("POST", "OPTIONS")
	strict.HandleFunc("/transaction/broadcast", s.submitSignedTransaction).Methods("POST", "OPTIONS")

	// ========== STANDARD RATE LIMITING (10 req/sec) ==========
	standard := api.PathPrefix("").Subrouter()
	standard.Use(s.RateLimitMiddleware("standard"))
	standard.HandleFunc("/estimate-gas", s.estimateGas).Methods("POST", "OPTIONS")

	// ========== PERMISSIVE RATE LIMITING (100 req/sec) ==========
	permissive := api.PathPrefix("").Subrouter()
	permissive.Use(s.RateLimitMiddleware("permissive"))

	// Account endpoints
	permissive.HandleFunc("/account/{address}/balance", s.getAccountBalance).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/account/{address}", s.getAccount).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/account/{address}/transactions", s.getAccountTransactions).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/account/{address}/delegations", s.getAccountDelegations).Methods("GET", "OPTIONS")

	// Staking endpoints
	permissive.HandleFunc("/account/{address}/stake", s.getAccountStake).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/account/{address}/rewards", s.getAccountRewards).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/staking/stats", s.getStakingStats).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/staking/validators", s.getStakingValidators).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/staking/delegations/{address}", s.getDelegationHistory).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/staking/rewards/{address}", s.getDetailedRewards).Methods("GET", "OPTIONS")

	// General Data endpoints
	permissive.HandleFunc("/transaction/{hash}", s.getTransaction).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/transactions/pending", s.getPendingTransactions).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/block/{hash}", s.getBlockByHash).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/block/height/{height}", s.getBlockByHeight).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/block/latest", s.getLatestBlock).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/validator/{address}", s.getValidator).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/validators", s.getValidators).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/validators/active", s.getActiveValidators).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/status", s.getStatus).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/health", s.getHealth).Methods("GET", "OPTIONS")
	permissive.HandleFunc("/validator/{address}/activity", s.getValidatorActivity).Methods("GET", "OPTIONS")

	// FIXED: CORS Configuration (Strict Security)
	// 1. Removed "*" and "chrome-extension://*"
	// 2. Removed PUT/DELETE methods (not needed for public API)
	// 3. Removed wildcard headers

	allowedOrigins := []string{
		"https://thrylos.org",
		"https://www.thrylos.org",
		"https://app.thrylos.org",
	}

	// Add localhost for development (can be conditional based on env if needed)
	allowedOrigins = append(allowedOrigins,
		"http://localhost:3000",
		"http://localhost:5173",
		"http://localhost:8080",
		"http://127.0.0.1:5173",
		"http://127.0.0.1:3000",
	)

	c := cors.New(cors.Options{
		AllowedOrigins: allowedOrigins,
		AllowedMethods: []string{"GET", "POST", "OPTIONS"}, // Read & Submit only
		AllowedHeaders: []string{
			"Content-Type",
			"Authorization",
			"Accept",
			"Origin",
			"X-Requested-With",
		},
		ExposedHeaders: []string{
			"Content-Length",
			"X-RateLimit-Limit",
			"X-RateLimit-Remaining",
			"Retry-After",
		},
		AllowCredentials: true,
		MaxAge:           300, // 5 minutes cache for preflight
		Debug:            false,
	})

	// Apply Middleware
	s.router.Use(c.Handler) // Applies CORS to all routes
	s.router.Use(s.loggingMiddleware)
	s.router.Use(s.jsonMiddleware)

	// REMOVED: The manual "s.router.Methods("OPTIONS").HandlerFunc..." block.
	// The cors library handles OPTIONS requests automatically and securely.
}

// Start starts the HTTP server
func (s *Server) Start() error {
	s.server = &http.Server{
		Addr:         fmt.Sprintf(":%d", s.port),
		Handler:      s.router,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	if s.enableTLS {
		log.Printf("🔒 HTTPS API Server starting on port %d", s.port)
		log.Printf("📊 Health check: https://localhost:%d/api/v1/health", s.port)
		log.Printf("💰 Account endpoint: https://localhost:%d/api/v1/account/{address}", s.port)
		return s.server.ListenAndServeTLS(s.certFile, s.keyFile)
	} else {
		log.Printf("🌐 HTTP API Server starting on port %d", s.port)
		log.Printf("📊 Health check: http://localhost:%d/api/v1/health", s.port)
		log.Printf("💰 Account endpoint: http://localhost:%d/api/v1/account/{address}", s.port)
		log.Printf("⚠️  Warning: Using HTTP in development mode. Use HTTPS for production!")
		return s.server.ListenAndServe()
	}
}

// Stop stops the HTTP server
func (s *Server) Stop() error {
	if s.server != nil {
		return s.server.Close()
	}
	return nil
}

func (s *Server) submitSignedTransaction(w http.ResponseWriter, r *http.Request) {
	var tx core.Transaction
	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
		s.writeError(w, "Invalid transaction format", http.StatusBadRequest)
		return
	}

	// Expect transaction to be fully formed and signed
	if tx.Id == "" {
		s.writeError(w, "Transaction ID required", http.StatusBadRequest)
		return
	}

	if tx.Hash == "" {
		s.writeError(w, "Transaction hash required", http.StatusBadRequest)
		return
	}

	if len(tx.Signature) == 0 {
		s.writeError(w, "Transaction signature required", http.StatusBadRequest)
		return
	}

	// Validate signature using your crypto system
	// This is where your existing validation logic goes
	if err := s.worldState.AddTransaction(&tx); err != nil {
		s.writeError(w, fmt.Sprintf("Invalid transaction: %v", err), http.StatusBadRequest)
		return
	}

	s.writeJSON(w, map[string]interface{}{
		"status":  "accepted",
		"tx_hash": tx.Hash,
	})
}

func (s *Server) estimateGas(w http.ResponseWriter, r *http.Request) {
	var req struct {
		From   string `json:"from"`
		To     string `json:"to"`
		Amount int64  `json:"amount"`
		Data   string `json:"data,omitempty"` // For smart contracts later
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.writeError(w, "Invalid request format", http.StatusBadRequest)
		return
	}

	// Basic gas estimation based on transaction type
	var gasEstimate int64 = 21000 // Standard transaction gas from your config

	// If there's data (smart contract call), increase gas
	if req.Data != "" {
		gasEstimate += int64(len(req.Data)) * 68 // Gas per byte
	}

	// Get current gas price from your config (1000 from config.go)
	gasPrice := int64(1000)

	// Calculate total fee
	totalFee := gasEstimate * gasPrice

	response := map[string]interface{}{
		"gas_estimate": gasEstimate,
		"gas_price":    gasPrice,
		"total_fee":    totalFee,
		"fee_thrylos":  float64(totalFee) / 1000000000, // Convert to THRYLOS
	}

	s.writeJSON(w, response)
}

// UPDATED Account endpoints for account-based system

func (s *Server) getAccount(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	account, err := s.worldState.GetAccount(address)
	if err != nil {
		s.writeError(w, "Account not found", http.StatusNotFound)
		return
	}

	// Get additional staking information using existing methods
	stakedAmount := account.StakedAmount
	rewards := account.Rewards
	delegations := account.DelegatedTo
	if delegations == nil {
		delegations = make(map[string]int64)
	}

	response := map[string]interface{}{
		"address":       account.Address,
		"balance":       account.Balance,
		"nonce":         account.Nonce,
		"staked_amount": stakedAmount,
		"rewards":       rewards,
		"delegated_to":  delegations,
	}

	s.writeJSON(w, response)
}

func (s *Server) getAccountBalance(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	balance, err := s.worldState.GetBalance(address)
	if err != nil {
		s.writeError(w, "Account not found", http.StatusNotFound)
		return
	}

	nonce, _ := s.worldState.GetNonce(address)

	// Convert to THRYLOS (1 THRYLOS = 1e9 nano based on your BaseUnit)
	const NANO_PER_THRYLOS = 1000000000
	balanceThrylos := float64(balance) / NANO_PER_THRYLOS

	response := map[string]interface{}{
		"address":        address,
		"balance":        balance,
		"balanceThrylos": balanceThrylos,
		"nonce":          nonce,
	}

	s.writeJSON(w, response)
}

func (s *Server) getAccountStake(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	account, err := s.worldState.GetAccount(address)
	if err != nil {
		s.writeError(w, "Account not found", http.StatusNotFound)
		return
	}

	response := map[string]interface{}{
		"address":       address,
		"staked_amount": account.StakedAmount,
	}

	s.writeJSON(w, response)
}

func (s *Server) getAccountRewards(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	account, err := s.worldState.GetAccount(address)
	if err != nil {
		s.writeError(w, "Account not found", http.StatusNotFound)
		return
	}

	response := map[string]interface{}{
		"address": address,
		"rewards": account.Rewards,
	}

	s.writeJSON(w, response)
}

func (s *Server) getAccountDelegations(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	// Use your existing StakingManager
	stakingManager := s.worldState.GetStakingManager()
	delegations, err := stakingManager.GetDelegations(address)
	if err != nil {
		s.writeError(w, "Failed to get delegations", http.StatusInternalServerError)
		return
	}

	response := map[string]interface{}{
		"address":     address,
		"delegations": delegations,
		"count":       len(delegations),
	}

	s.writeJSON(w, response)
}

func (s *Server) getAccountTransactions(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	// Add debug logging
	log.Printf("🔍 Getting transactions for address: %s", address)

	// Parse query parameters
	limitStr := r.URL.Query().Get("limit")
	limit := 50 // default limit
	if limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err == nil && parsedLimit > 0 && parsedLimit <= 1000 {
			limit = parsedLimit
		}
	}

	var accountTxs []map[string]interface{}

	// Get confirmed transactions using efficient indexing
	// ACCESS DB THROUGH WORLDSTATE
	log.Printf("🔍 Fetching confirmed transactions from database index...")
	confirmedTxs, err := s.worldState.GetTransactionsByAddress(address, limit)
	if err != nil {
		log.Printf("❌ Error getting transactions for address %s: %v", address, err)
		http.Error(w, "Failed to fetch transactions", http.StatusInternalServerError)
		return
	}

	log.Printf("🔍 Found %d confirmed transactions", len(confirmedTxs))

	// Convert confirmed transactions to response format
	for _, tx := range confirmedTxs {
		if len(accountTxs) >= limit {
			break
		}

		txData := map[string]interface{}{
			"hash":      tx.Id,
			"from":      tx.From,
			"to":        tx.To,
			"amount":    tx.Amount,
			"nonce":     tx.Nonce,
			"gas":       tx.Gas,
			"gas_price": tx.GasPrice,
			"timestamp": tx.Timestamp,
			"status":    "confirmed",
		}
		accountTxs = append(accountTxs, txData)
	}

	// Add pending transactions (still check these for real-time updates)
	pendingTxs := s.worldState.GetPendingTransactions()
	log.Printf("🔍 Checking %d pending transactions", len(pendingTxs))

	for _, tx := range pendingTxs {
		if len(accountTxs) >= limit {
			break
		}

		if tx.From == address || tx.To == address {
			log.Printf("🔍 Found pending transaction: %s", tx.Id)

			txData := map[string]interface{}{
				"hash":      tx.Id,
				"from":      tx.From,
				"to":        tx.To,
				"amount":    tx.Amount,
				"nonce":     tx.Nonce,
				"gas":       tx.Gas,
				"gas_price": tx.GasPrice,
				"timestamp": tx.Timestamp,
				"status":    "pending",
			}
			accountTxs = append(accountTxs, txData)
		}
	}

	// Sort all transactions by timestamp (newest first)
	sort.Slice(accountTxs, func(i, j int) bool {
		timeI, okI := accountTxs[i]["timestamp"].(int64)
		timeJ, okJ := accountTxs[j]["timestamp"].(int64)
		if !okI || !okJ {
			return false
		}
		return timeI > timeJ
	})

	log.Printf("✅ Returning %d total transactions for address %s", len(accountTxs), address)

	response := map[string]interface{}{
		"address":      address,
		"transactions": accountTxs,
		"count":        len(accountTxs),
		"limit":        limit,
	}

	s.writeJSON(w, response)
}

// Development endpoint to fund addresses (for testing)
// SECURITY: Only enabled in development/testnet environments
func (s *Server) fundAddress(w http.ResponseWriter, r *http.Request) {
	// CRITICAL: Only allow in development/testnet
	// Ethereum/Solana approach: use environment checks, not API keys
	if !isDevEnvironment() {
		s.writeError(w, "Funding endpoint not available in production", http.StatusForbidden)
		return
	}

	var req struct {
		Address string `json:"address"`
		Amount  int64  `json:"amount"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.writeError(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	if req.Address == "" || req.Amount <= 0 {
		s.writeError(w, "Invalid address or amount", http.StatusBadRequest)
		return
	}

	// Additional safety: Limit funding amount
	const MAX_FUND_AMOUNT = 1000 * 1000000000 // 1000 THRYLOS max per request
	if req.Amount > MAX_FUND_AMOUNT {
		s.writeError(w, fmt.Sprintf("Funding amount exceeds maximum of %d nano", MAX_FUND_AMOUNT), http.StatusBadRequest)
		return
	}

	// Try to get existing account first
	account, err := s.worldState.GetAccount(req.Address)
	if err != nil {
		// Account doesn't exist, create a new one
		account = &core.Account{
			Address:      req.Address,
			Balance:      req.Amount, // Set initial balance
			Nonce:        0,
			StakedAmount: 0,
			DelegatedTo:  make(map[string]int64),
			Rewards:      0,
		}
	} else {
		// Account exists, add funding to existing balance
		account.Balance += req.Amount
	}

	// Use the proper WorldState method to update with storage persistence
	if err := s.worldState.UpdateAccountWithStorage(account); err != nil {
		s.writeError(w, fmt.Sprintf("Failed to create/update account: %v", err), http.StatusInternalServerError)
		return
	}

	// Convert to THRYLOS for display
	const NANO_PER_THRYLOS = 1000000000
	balanceThrylos := float64(account.Balance) / NANO_PER_THRYLOS
	amountThrylos := float64(req.Amount) / NANO_PER_THRYLOS

	response := map[string]interface{}{
		"message":         "Account funded successfully",
		"address":         req.Address,
		"amount_added":    req.Amount,
		"amount_thrylos":  amountThrylos,
		"new_balance":     account.Balance,
		"balance_thrylos": balanceThrylos,
		"nonce":           account.Nonce,
	}

	s.writeJSON(w, response)
}

// isDevEnvironment checks if we're running in a development environment
// Ethereum/Solana approach: environment-based, not authentication-based
func isDevEnvironment() bool {
	env := os.Getenv("THRYLOS_ENVIRONMENT")

	// Allow in: development, devnet, testnet
	// Block in: production, mainnet
	switch env {
	case "development", "dev", "devnet", "testnet", "test":
		return true
	case "production", "prod", "mainnet":
		return false
	default:
		// Default to development for safety during testing
		// In production, explicitly set THRYLOS_ENVIRONMENT=production
		return true
	}
}

// Transaction endpoints (keep existing implementation)

func (s *Server) getTransaction(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	hash := vars["hash"]

	// Try to get from storage first
	tx, err := s.worldState.GetTransactionFromStorage(hash)
	if err != nil {
		// Check pending transactions
		pendingTxs := s.worldState.GetPendingTransactions()
		for _, pendingTx := range pendingTxs {
			if pendingTx.Id == hash {
				tx = pendingTx
				break
			}
		}
	}

	if tx == nil {
		s.writeError(w, "Transaction not found", http.StatusNotFound)
		return
	}

	response := TransactionResponse{
		Hash:      tx.Id,
		From:      tx.From,
		To:        tx.To,
		Amount:    tx.Amount,
		Nonce:     tx.Nonce,
		Gas:       tx.Gas,
		GasPrice:  tx.GasPrice,
		Timestamp: tx.Timestamp,
		Status:    "confirmed", // or determine actual status
	}

	s.writeJSON(w, response)
}

func (s *Server) getPendingTransactions(w http.ResponseWriter, r *http.Request) {
	// Parse query parameters
	limitStr := r.URL.Query().Get("limit")
	limit := 100 // default limit
	if limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err == nil && parsedLimit > 0 && parsedLimit <= 1000 {
			limit = parsedLimit
		}
	}

	pendingTxs := s.worldState.GetPendingTransactions()

	var transactions []TransactionResponse
	for i, tx := range pendingTxs {
		if i >= limit {
			break
		}

		txResponse := TransactionResponse{
			Hash:      tx.Id,
			From:      tx.From,
			To:        tx.To,
			Amount:    tx.Amount,
			Nonce:     tx.Nonce,
			Gas:       tx.Gas,
			GasPrice:  tx.GasPrice,
			Timestamp: tx.Timestamp,
			Status:    "pending",
		}
		transactions = append(transactions, txResponse)
	}

	response := map[string]interface{}{
		"transactions": transactions,
		"count":        len(transactions),
		"limit":        limit,
	}

	s.writeJSON(w, response)
}

func (s *Server) getBlockByHash(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	hash := vars["hash"]

	block, err := s.worldState.GetBlockByHash(hash)
	if err != nil {
		// Try storage
		block, err = s.worldState.GetBlockFromStorage(hash)
		if err != nil {
			s.writeError(w, "Block not found", http.StatusNotFound)
			return
		}
	}

	response := s.formatBlock(block)
	s.writeJSON(w, response)
}

func (s *Server) getBlockByHeight(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	heightStr := vars["height"]

	height, err := strconv.ParseInt(heightStr, 10, 64)
	if err != nil {
		s.writeError(w, "Invalid height", http.StatusBadRequest)
		return
	}

	block, err := s.worldState.GetBlock(height)
	if err != nil {
		s.writeError(w, "Block not found", http.StatusNotFound)
		return
	}

	response := s.formatBlock(block)
	s.writeJSON(w, response)
}

func (s *Server) getLatestBlock(w http.ResponseWriter, r *http.Request) {
	block := s.worldState.GetCurrentBlock()
	if block == nil {
		s.writeError(w, "No blocks found", http.StatusNotFound)
		return
	}

	response := s.formatBlock(block)
	s.writeJSON(w, response)
}

func (s *Server) getValidator(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	validator, err := s.worldState.GetValidator(address)
	if err != nil {
		s.writeError(w, "Validator not found", http.StatusNotFound)
		return
	}

	response := s.formatValidator(validator)
	s.writeJSON(w, response)
}

func (s *Server) getValidators(w http.ResponseWriter, r *http.Request) {
	// Parse query parameters
	limitStr := r.URL.Query().Get("limit")
	limit := 100 // default limit
	if limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err == nil && parsedLimit > 0 && parsedLimit <= 1000 {
			limit = parsedLimit
		}
	}

	activeOnly := r.URL.Query().Get("active") == "true"

	var validators []map[string]interface{}

	if activeOnly {
		activeValidators := s.worldState.GetActiveValidators()
		for i, validator := range activeValidators {
			if i >= limit {
				break
			}
			validators = append(validators, s.formatValidator(validator))
		}
	} else {
		// Get all validators (you'd need to implement GetAllValidators)
		// For now, return active validators
		activeValidators := s.worldState.GetActiveValidators()
		for i, validator := range activeValidators {
			if i >= limit {
				break
			}
			validators = append(validators, s.formatValidator(validator))
		}
	}

	response := map[string]interface{}{
		"validators": validators,
		"count":      len(validators),
		"limit":      limit,
	}

	s.writeJSON(w, response)
}

func (s *Server) getActiveValidators(w http.ResponseWriter, r *http.Request) {
	activeValidators := s.worldState.GetActiveValidators()

	var validators []map[string]interface{}
	for _, validator := range activeValidators {
		validators = append(validators, s.formatValidator(validator))
	}

	response := map[string]interface{}{
		"validators": validators,
		"count":      len(validators),
	}

	s.writeJSON(w, response)
}

func (s *Server) getStatus(w http.ResponseWriter, r *http.Request) {
	status := s.worldState.GetStatus()
	s.writeJSON(w, status)
}

func (s *Server) getHealth(w http.ResponseWriter, r *http.Request) {
	health := map[string]interface{}{
		"status":    "healthy",
		"timestamp": time.Now().Unix(),
		"height":    s.worldState.GetHeight(),
		"version":   "1.0.0",
	}
	s.writeJSON(w, health)
}

func (s *Server) formatBlock(block *core.Block) map[string]interface{} {
	var transactions []TransactionResponse
	for _, tx := range block.Transactions {
		txResponse := TransactionResponse{
			Hash:     tx.Id,
			From:     tx.From,
			To:       tx.To,
			Amount:   tx.Amount,
			Nonce:    tx.Nonce,
			Gas:      tx.Gas,
			GasPrice: tx.GasPrice,
		}
		transactions = append(transactions, txResponse)
	}

	return map[string]interface{}{
		"hash":         block.Hash,
		"height":       block.Header.Index,
		"prev_hash":    block.Header.PrevHash,
		"state_root":   block.Header.StateRoot,
		"timestamp":    block.Header.Timestamp,
		"gas_used":     block.Header.GasUsed,
		"gas_limit":    block.Header.GasLimit,
		"validator":    block.Header.Validator,
		"transactions": transactions,
		"tx_count":     len(block.Transactions),
	}
}
func (s *Server) formatValidator(validator *core.Validator) map[string]interface{} {
	// Convert boolean Active to string status
	status := "inactive"
	if validator.Active {
		status = "active"
	}

	// Handle jailed validators
	if validator.JailUntil > 0 && time.Now().Unix() < validator.JailUntil {
		status = "jailed"
	}

	return map[string]interface{}{
		"address":        validator.Address,
		"name":           validator.Name,
		"description":    validator.Description,
		"website":        validator.Website,
		"commission":     validator.Commission,
		"totalStaked":    validator.Stake + validator.DelegatedStake, // Combined stake
		"uptime":         s.calculateValidatorUptime(validator),
		"status":         status, // ✅ Fixed: string instead of boolean
		"selfStake":      validator.SelfStake,
		"delegatorCount": len(validator.Delegators),
		"blocksProposed": validator.BlocksProposed,
		"blocksMissed":   validator.BlocksMissed,
		"createdAt":      validator.CreatedAt,
		"updatedAt":      validator.UpdatedAt,
		"delegations":    validator.Delegators,

		// Keep the old fields for backward compatibility
		"active":          validator.Active,
		"stake":           validator.Stake,
		"self_stake":      validator.SelfStake,
		"delegated_stake": validator.DelegatedStake,
		"blocks_proposed": validator.BlocksProposed,
		"blocks_missed":   validator.BlocksMissed,
		"jail_until":      validator.JailUntil,
		"created_at":      validator.CreatedAt,
		"updated_at":      validator.UpdatedAt,
		"delegator_count": len(validator.Delegators),
	}
}

// Add this helper function
func (s *Server) calculateValidatorUptime(validator *core.Validator) float64 {
	totalBlocks := validator.BlocksProposed + validator.BlocksMissed
	if totalBlocks == 0 {
		return 100.0 // New validators start with 100% uptime
	}
	return (float64(validator.BlocksProposed) / float64(totalBlocks)) * 100.0
}

func (s *Server) writeJSON(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(data); err != nil {
		log.Printf("Error encoding JSON: %v", err)
		http.Error(w, "Internal server error", http.StatusInternalServerError)
	}
}

func (s *Server) writeError(w http.ResponseWriter, message string, statusCode int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"error":     message,
		"status":    statusCode,
		"timestamp": time.Now().Unix(),
	})
}

// Middleware (keep existing)

func (s *Server) loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()

		// Create a custom ResponseWriter to capture status code
		lrw := &loggingResponseWriter{ResponseWriter: w, statusCode: http.StatusOK}

		next.ServeHTTP(lrw, r)

		duration := time.Since(start)
		log.Printf("%s %s %d %v", r.Method, r.URL.Path, lrw.statusCode, duration)
	})
}

func (s *Server) jsonMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		next.ServeHTTP(w, r)
	})
}

type loggingResponseWriter struct {
	http.ResponseWriter
	statusCode int
}

func (lrw *loggingResponseWriter) WriteHeader(code int) {
	lrw.statusCode = code
	lrw.ResponseWriter.WriteHeader(code)
}

type StakingStatsResponse struct {
	TotalStaked           int64   `json:"total_staked"`
	AnnualPercentageYield float64 `json:"annual_percentage_yield"`
	NextRewardTime        *int64  `json:"next_reward_time"`
	UnbondingPeriod       int     `json:"unbonding_period"`
	ActiveValidators      int     `json:"active_validators"`
	TotalDelegators       int     `json:"total_delegators"`
	AverageCommission     float64 `json:"average_commission"`
}

type StakingValidatorResponse struct {
	Address        string  `json:"address"`
	Name           string  `json:"name"`
	Description    string  `json:"description"` // Add this field
	Website        string  `json:"website"`     // Add this field
	Commission     float64 `json:"commission"`
	TotalStaked    int64   `json:"totalStaked"`
	Uptime         float64 `json:"uptime"`
	Status         string  `json:"status"`
	SelfStake      int64   `json:"selfStake"`
	DelegatorCount int     `json:"delegatorCount"`
	BlocksProposed int64   `json:"blocksProposed"`
	BlocksMissed   int64   `json:"blocksMissed"`
	CreatedAt      int64   `json:"createdAt"` // Add this field
	UpdatedAt      int64   `json:"updatedAt"` // Add this field
}

type DelegationHistoryItem struct {
	Validator string `json:"validator"`
	Amount    int64  `json:"amount"`
	Timestamp int64  `json:"timestamp"`
	Status    string `json:"status"`
	TxHash    string `json:"tx_hash"`
	Action    string `json:"action"` // "delegate", "undelegate", "claim"
}

type DelegationHistoryResponse struct {
	Address string                  `json:"address"`
	History []DelegationHistoryItem `json:"history"`
	Count   int                     `json:"count"`
}

// ========== ENDPOINT IMPLEMENTATIONS ==========

// 1. Get staking statistics
func (s *Server) getStakingStats(w http.ResponseWriter, r *http.Request) {
	activeValidators := s.worldState.GetActiveValidators()
	totalStaked := s.worldState.GetTotalStaked()
	activeValidatorCount := len(activeValidators)

	totalCommission := float64(0)
	totalDelegators := 0

	for _, validator := range activeValidators {
		totalCommission += validator.Commission
		totalDelegators += len(validator.Delegators)
	}

	averageCommission := float64(0)
	if activeValidatorCount > 0 {
		averageCommission = totalCommission / float64(activeValidatorCount)
	}

	// Base APY - you can get this from config if available
	baseAPY := float64(8.5)

	// Next reward time based on your block time
	nextRewardTime := time.Now().Unix() + 200 // 200ms from your config

	response := StakingStatsResponse{
		TotalStaked:           totalStaked,
		AnnualPercentageYield: baseAPY,
		NextRewardTime:        &nextRewardTime,
		UnbondingPeriod:       21, // Days
		ActiveValidators:      activeValidatorCount,
		TotalDelegators:       totalDelegators,
		AverageCommission:     averageCommission,
	}

	s.writeJSON(w, response)
}

// 2. Get validators formatted for staking interface
func (s *Server) getStakingValidators(w http.ResponseWriter, r *http.Request) {
	activeValidators := s.worldState.GetActiveValidators()

	var validators []StakingValidatorResponse
	for _, validator := range activeValidators {
		// Calculate uptime percentage
		uptime := float64(100) // Default to 100%
		if validator.BlocksProposed > 0 {
			total := validator.BlocksProposed + validator.BlocksMissed
			uptime = float64(validator.BlocksProposed) / float64(total) * 100
		}

		// Use actual validator name if available, otherwise generate fallback
		name := validator.Name
		if name == "" {
			name = fmt.Sprintf("Validator %s", validator.Address[:12])
		}

		// More robust status determination
		status := "active" // Default to active

		currentTime := time.Now().Unix()

		// Check if jailed
		if validator.JailUntil > currentTime {
			status = "jailed"
		} else {
			// If not jailed, check if explicitly marked as inactive
			// OR if it has very low activity (no blocks proposed and old)
			if !validator.Active {
				status = "inactive"
			} else if validator.BlocksProposed == 0 &&
				validator.CreatedAt > 0 &&
				(currentTime-validator.CreatedAt) > 3600 { // Created more than 1 hour ago but no blocks
				status = "inactive"
			} else {
				status = "active"
			}
		}

		validatorResponse := StakingValidatorResponse{
			Address:        validator.Address,
			Name:           name,
			Description:    validator.Description,
			Website:        validator.Website,
			Commission:     validator.Commission,
			TotalStaked:    validator.Stake,
			Uptime:         uptime,
			Status:         status,
			SelfStake:      validator.SelfStake,
			DelegatorCount: len(validator.Delegators),
			BlocksProposed: validator.BlocksProposed,
			BlocksMissed:   validator.BlocksMissed,
			CreatedAt:      validator.CreatedAt,
			UpdatedAt:      validator.UpdatedAt,
		}

		validators = append(validators, validatorResponse)
	}

	response := map[string]interface{}{
		"validators": validators,
		"count":      len(validators),
	}

	s.writeJSON(w, response)
}

// 3. Submit staking/delegation transaction using your existing executor
// func (s *Server) submitStakeTransaction(w http.ResponseWriter, r *http.Request) {
// 	var tx core.Transaction
// 	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
// 		s.writeError(w, "Invalid transaction format", http.StatusBadRequest)
// 		return
// 	}

// 	// Your executor handles DELEGATE transactions
// 	// Set the correct transaction type for your executor
// 	tx.Type = core.TransactionType_DELEGATE

// 	// Validate required fields
// 	if tx.From == "" || tx.To == "" || tx.Amount <= 0 {
// 		s.writeError(w, "Invalid staking transaction: missing required fields", http.StatusBadRequest)
// 		return
// 	}

// 	// Validate signature
// 	if len(tx.Signature) == 0 {
// 		s.writeError(w, "Transaction signature required", http.StatusBadRequest)
// 		return
// 	}

// 	// Use your existing validation and execution system
// 	if err := s.worldState.ValidateTransaction(&tx); err != nil {
// 		s.writeError(w, fmt.Sprintf("Transaction validation failed: %v", err), http.StatusBadRequest)
// 		return
// 	}

// 	// Add to transaction pool - your executor will handle it when block is created
// 	if err := s.worldState.AddTransaction(&tx); err != nil {
// 		s.writeError(w, fmt.Sprintf("Failed to submit staking transaction: %v", err), http.StatusBadRequest)
// 		return
// 	}

// 	response := map[string]interface{}{
// 		"status":    "accepted",
// 		"tx_hash":   tx.Hash,
// 		"message":   "Delegation transaction submitted successfully",
// 		"validator": tx.To,
// 		"amount":    tx.Amount,
// 	}

// 	s.writeJSON(w, response)
// }

// 4. Submit unstaking transaction
// func (s *Server) submitUnstakeTransaction(w http.ResponseWriter, r *http.Request) {
// 	var tx core.Transaction
// 	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
// 		s.writeError(w, "Invalid transaction format", http.StatusBadRequest)
// 		return
// 	}

// 	// Set the correct transaction type for your executor
// 	tx.Type = core.TransactionType_UNDELEGATE

// 	// Validate required fields
// 	if tx.From == "" || tx.To == "" || tx.Amount <= 0 {
// 		s.writeError(w, "Invalid unstaking transaction: missing required fields", http.StatusBadRequest)
// 		return
// 	}

// 	// Validate signature
// 	if len(tx.Signature) == 0 {
// 		s.writeError(w, "Transaction signature required", http.StatusBadRequest)
// 		return
// 	}

// 	// Check if user has enough delegated amount
// 	account, err := s.worldState.GetAccount(tx.From)
// 	if err != nil {
// 		s.writeError(w, "Account not found", http.StatusNotFound)
// 		return
// 	}

// 	delegatedAmount := int64(0)
// 	if account.DelegatedTo != nil {
// 		if amount, exists := account.DelegatedTo[tx.To]; exists {
// 			delegatedAmount = amount
// 		}
// 	}

// 	if tx.Amount > delegatedAmount {
// 		s.writeError(w, fmt.Sprintf("Insufficient delegation: have %d, need %d",
// 			delegatedAmount, tx.Amount), http.StatusBadRequest)
// 		return
// 	}

// 	// Use your existing validation and execution system
// 	if err := s.worldState.ValidateTransaction(&tx); err != nil {
// 		s.writeError(w, fmt.Sprintf("Transaction validation failed: %v", err), http.StatusBadRequest)
// 		return
// 	}

// 	if err := s.worldState.AddTransaction(&tx); err != nil {
// 		s.writeError(w, fmt.Sprintf("Failed to submit unstaking transaction: %v", err), http.StatusBadRequest)
// 		return
// 	}

// 	response := map[string]interface{}{
// 		"status":           "accepted",
// 		"tx_hash":          tx.Hash,
// 		"message":          "Undelegation transaction submitted successfully",
// 		"validator":        tx.To,
// 		"amount":           tx.Amount,
// 		"unbonding_period": 0, // Your system uses liquid staking (immediate)
// 	}

// 	s.writeJSON(w, response)
// }

// 5. Submit reward claiming transaction
// func (s *Server) submitClaimTransaction(w http.ResponseWriter, r *http.Request) {
// 	var tx core.Transaction
// 	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
// 		s.writeError(w, "Invalid transaction format", http.StatusBadRequest)
// 		return
// 	}

// 	// Set the correct transaction type for your executor
// 	tx.Type = core.TransactionType_CLAIM_REWARDS

// 	// For claim transactions, amount should be 0 (claims all available rewards)
// 	tx.Amount = 0
// 	tx.To = tx.From // Self-transaction for claiming

// 	// Validate required fields
// 	if tx.From == "" {
// 		s.writeError(w, "Invalid claim transaction: missing sender", http.StatusBadRequest)
// 		return
// 	}

// 	// Validate signature
// 	if len(tx.Signature) == 0 {
// 		s.writeError(w, "Transaction signature required", http.StatusBadRequest)
// 		return
// 	}

// 	// Check if user has rewards to claim
// 	account, err := s.worldState.GetAccount(tx.From)
// 	if err != nil {
// 		s.writeError(w, "Account not found", http.StatusNotFound)
// 		return
// 	}

// 	if account.Rewards <= 0 {
// 		s.writeError(w, "No rewards available to claim", http.StatusBadRequest)
// 		return
// 	}

// 	// Use your existing validation and execution system
// 	if err := s.worldState.ValidateTransaction(&tx); err != nil {
// 		s.writeError(w, fmt.Sprintf("Transaction validation failed: %v", err), http.StatusBadRequest)
// 		return
// 	}

// 	if err := s.worldState.AddTransaction(&tx); err != nil {
// 		s.writeError(w, fmt.Sprintf("Failed to submit claim transaction: %v", err), http.StatusBadRequest)
// 		return
// 	}

// 	response := map[string]interface{}{
// 		"status":         "accepted",
// 		"tx_hash":        tx.Hash,
// 		"message":        "Claim transaction submitted successfully",
// 		"claimed_amount": account.Rewards,
// 	}

// 	s.writeJSON(w, response)
// }

// 6. Get delegation history
func (s *Server) getDelegationHistory(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	// Parse query parameters
	limitStr := r.URL.Query().Get("limit")
	limit := 50 // default limit
	if limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err == nil && parsedLimit > 0 && parsedLimit <= 1000 {
			limit = parsedLimit
		}
	}

	// Get current delegations from account
	var history []DelegationHistoryItem

	account, err := s.worldState.GetAccount(address)
	if err != nil {
		// Account might not exist, return empty history
		history = []DelegationHistoryItem{}
	} else {
		// Convert current delegations to history format
		if account.DelegatedTo != nil {
			for validator, amount := range account.DelegatedTo {
				if len(history) >= limit {
					break
				}

				history = append(history, DelegationHistoryItem{
					Validator: validator,
					Amount:    amount,
					Timestamp: time.Now().Unix(),
					Status:    "active",
					TxHash:    "", // Would need transaction indexing for real tx hash
					Action:    "delegate",
				})
			}
		}
	}

	response := DelegationHistoryResponse{
		Address: address,
		History: history,
		Count:   len(history),
	}

	s.writeJSON(w, response)
}

// 7. Get detailed rewards information
func (s *Server) getDetailedRewards(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	account, err := s.worldState.GetAccount(address)
	if err != nil {
		s.writeError(w, "Account not found", http.StatusNotFound)
		return
	}

	// Calculate estimated rewards based on current delegations
	estimatedDaily := float64(0)
	estimatedMonthly := float64(0)
	estimatedAnnual := float64(0)

	baseAPY := 8.5 / 100 // 8.5% annual yield

	if account.DelegatedTo != nil {
		for validatorAddr, stakedAmount := range account.DelegatedTo {
			validator, err := s.worldState.GetValidator(validatorAddr)
			if err != nil {
				continue
			}

			// Calculate rewards considering validator commission
			netAPY := baseAPY * (1 - validator.Commission/100)
			annualReward := float64(stakedAmount) * netAPY

			estimatedAnnual += annualReward
			estimatedMonthly += annualReward / 12
			estimatedDaily += annualReward / 365
		}
	}

	response := map[string]interface{}{
		"address":           address,
		"current_rewards":   account.Rewards,
		"estimated_daily":   int64(estimatedDaily),
		"estimated_monthly": int64(estimatedMonthly),
		"estimated_annual":  int64(estimatedAnnual),
		"delegations":       account.DelegatedTo,
		"staked_amount":     account.StakedAmount,
	}

	s.writeJSON(w, response)
}

// func (s *Server) createValidator(w http.ResponseWriter, r *http.Request) {
// 	var tx core.Transaction
// 	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
// 		s.writeError(w, "Invalid transaction format", http.StatusBadRequest)
// 		return
// 	}

// 	log.Printf("Received validator creation transaction: %+v", tx)

// 	// Validate required fields for validator creation
// 	if tx.From == "" {
// 		s.writeError(w, "Validator address (from) is required", http.StatusBadRequest)
// 		return
// 	}

// 	if tx.Hash == "" {
// 		s.writeError(w, "Transaction hash is required", http.StatusBadRequest)
// 		return
// 	}

// 	if len(tx.Signature) == 0 {
// 		s.writeError(w, "Transaction signature is required", http.StatusBadRequest)
// 		return
// 	}

// 	// For validator transactions, we might use a different transaction type
// 	// Check if it's type 6 from frontend or adjust based on your system
// 	if tx.Type != 6 {
// 		log.Printf("Warning: Expected type 6 for validator creation, got %d", tx.Type)
// 		// Force set to validator creation type
// 		tx.Type = 6
// 	}

// 	// Parse validator data from transaction data field
// 	var validatorData struct {
// 		Type        string  `json:"type"`
// 		Name        string  `json:"name"`
// 		Description string  `json:"description"`
// 		Website     string  `json:"website"`
// 		Commission  float64 `json:"commission"`
// 		SelfStake   int64   `json:"self_stake"`
// 	}

// 	if len(tx.Data) > 0 {
// 		if err := json.Unmarshal(tx.Data, &validatorData); err != nil {
// 			s.writeError(w, "Invalid validator data format", http.StatusBadRequest)
// 			return
// 		}
// 	}

// 	// Validate validator data
// 	if validatorData.Name == "" {
// 		s.writeError(w, "Validator name is required", http.StatusBadRequest)
// 		return
// 	}

// 	if validatorData.Commission < 0 || validatorData.Commission > 1 {
// 		s.writeError(w, "Validator commission must be between 0 and 1", http.StatusBadRequest)
// 		return
// 	}

// 	// Check minimum stake requirement (25 THRYLOS = 25 * 1e9 nano)
// 	const MIN_VALIDATOR_STAKE = 25 * 1000000000
// 	if tx.Amount < MIN_VALIDATOR_STAKE {
// 		s.writeError(w, fmt.Sprintf("Minimum validator stake is %d nano (25 THRYLOS)", MIN_VALIDATOR_STAKE), http.StatusBadRequest)
// 		return
// 	}

// 	// Check if validator already exists
// 	existingValidator, err := s.worldState.GetValidator(tx.From)
// 	if err == nil && existingValidator != nil {
// 		s.writeError(w, "Validator already exists for this address", http.StatusBadRequest)
// 		return
// 	}

// 	// Check account balance
// 	account, err := s.worldState.GetAccount(tx.From)
// 	if err != nil {
// 		s.writeError(w, "Account not found", http.StatusNotFound)
// 		return
// 	}

// 	totalCost := tx.Amount + (tx.Gas * tx.GasPrice)
// 	if account.Balance < totalCost {
// 		s.writeError(w, fmt.Sprintf("Insufficient balance: have %d, need %d", account.Balance, totalCost), http.StatusBadRequest)
// 		return
// 	}

// 	// Validate nonce
// 	if account.Nonce != tx.Nonce {
// 		s.writeError(w, fmt.Sprintf("Invalid nonce: expected %d, got %d", account.Nonce, tx.Nonce), http.StatusBadRequest)
// 		return
// 	}

// 	// Create the validator object with all metadata
// 	dummyPubkey := make([]byte, 32)
// 	copy(dummyPubkey, []byte(tx.From)) // Use address as temp pubkey

// 	validator := &core.Validator{
// 		Address:        tx.From,
// 		Pubkey:         dummyPubkey,
// 		Name:           validatorData.Name,        // Add name
// 		Description:    validatorData.Description, // Add description
// 		Website:        validatorData.Website,     // Add website
// 		Stake:          tx.Amount,
// 		SelfStake:      tx.Amount,
// 		DelegatedStake: 0,
// 		Commission:     validatorData.Commission,
// 		Active:         true,
// 		BlocksProposed: 0,
// 		BlocksMissed:   0,
// 		JailUntil:      0,
// 		CreatedAt:      time.Now().Unix(),
// 		UpdatedAt:      time.Now().Unix(),
// 		Delegators:     make(map[string]int64),
// 	}

// 	// Add validator to the system
// 	if err := s.worldState.AddValidator(validator); err != nil {
// 		s.writeError(w, fmt.Sprintf("Failed to create validator: %v", err), http.StatusInternalServerError)
// 		return
// 	}

// 	// Update account - deduct staked amount and gas fees
// 	account.Balance -= totalCost
// 	account.StakedAmount += tx.Amount
// 	account.Nonce++

// 	if err := s.worldState.UpdateAccountWithStorage(account); err != nil {
// 		s.writeError(w, fmt.Sprintf("Failed to update account: %v", err), http.StatusInternalServerError)
// 		return
// 	}

// 	// Optionally validate the transaction signature if needed
// 	if err := s.worldState.ValidateTransaction(&tx); err != nil {
// 		log.Printf("Warning: Transaction validation failed (proceeding anyway): %v", err)
// 	}

// 	// Add transaction to pending pool for inclusion in next block
// 	if err := s.worldState.AddTransaction(&tx); err != nil {
// 		log.Printf("Warning: Failed to add validator creation transaction to pool: %v", err)
// 	}

// 	log.Printf("Validator created successfully: %s (%s) with stake %d", validatorData.Name, tx.From, tx.Amount)

// 	// Return success response
// 	response := map[string]interface{}{
// 		"status":  "success",
// 		"message": "Validator created successfully",
// 		"tx_hash": tx.Hash,
// 		"validator": map[string]interface{}{
// 			"address":     validator.Address,
// 			"name":        validator.Name,        // Include name in response
// 			"description": validator.Description, // Include description in response
// 			"website":     validator.Website,     // Include website in response
// 			"commission":  validator.Commission,
// 			"self_stake":  validator.SelfStake,
// 			"total_stake": validator.Stake,
// 			"active":      validator.Active,
// 			"created_at":  validator.CreatedAt,
// 		},
// 	}

// 	s.writeJSON(w, response)
// }

type ValidatorActivityItem struct {
	Type      string `json:"type"`      // "block", "delegation", "commission", "withdrawal"
	Details   string `json:"details"`   // Human readable description
	Time      string `json:"time"`      // Human readable time
	Timestamp int64  `json:"timestamp"` // Unix timestamp
	Reward    *int64 `json:"reward"`    // Reward amount in nano (nullable)
	Amount    *int64 `json:"amount"`    // Transaction amount in nano (nullable)
	TxHash    string `json:"tx_hash"`   // Transaction hash if applicable
	From      string `json:"from"`      // Address for delegation events
}

type ValidatorActivityResponse struct {
	Address  string                  `json:"address"`
	Activity []ValidatorActivityItem `json:"activity"`
	Count    int                     `json:"count"`
	Limit    int                     `json:"limit"`
}

// Add this function to your server.go file
func (s *Server) getValidatorActivity(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	// Parse query parameters
	limitStr := r.URL.Query().Get("limit")
	limit := 50 // default limit
	if limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err == nil && parsedLimit > 0 && parsedLimit <= 1000 {
			limit = parsedLimit
		}
	}

	// Check if validator exists
	validator, err := s.worldState.GetValidator(address)
	if err != nil {
		s.writeError(w, "Validator not found", http.StatusNotFound)
		return
	}

	var activity []ValidatorActivityItem

	// 1. Get block validation activity
	if validator.BlocksProposed > 0 {
		// Get recent blocks validated by this validator
		activity = append(activity, s.getBlockValidationActivity(address, validator)...)
	}

	// 2. Get delegation activity
	delegationActivity := s.getDelegationActivity(address, validator)
	activity = append(activity, delegationActivity...)

	// 3. Get commission earnings activity
	commissionActivity := s.getCommissionActivity(address, validator)
	activity = append(activity, commissionActivity...)

	// 4. Sort by timestamp (most recent first)
	sort.Slice(activity, func(i, j int) bool {
		return activity[i].Timestamp > activity[j].Timestamp
	})

	// 5. Apply limit
	if len(activity) > limit {
		activity = activity[:limit]
	}

	response := ValidatorActivityResponse{
		Address:  address,
		Activity: activity,
		Count:    len(activity),
		Limit:    limit,
	}

	s.writeJSON(w, response)
}

// Helper function to get block validation activity
func (s *Server) getBlockValidationActivity(address string, validator *core.Validator) []ValidatorActivityItem {
	var activity []ValidatorActivityItem

	// Use actual block reward from config: 0.02 THRYLOS = 20,000,000 nano
	const BASE_BLOCK_REWARD int64 = 20000000 // BlockReward from config.go

	// Generate recent block validation events based on blocks proposed
	// This is a simplified version - in a real system you'd query actual block history
	blocksToShow := int64(5) // Show last 5 blocks
	if validator.BlocksProposed < blocksToShow {
		blocksToShow = validator.BlocksProposed
	}

	currentTime := time.Now().Unix()

	for i := int64(0); i < blocksToShow; i++ {
		blockNumber := validator.BlocksProposed - i
		timeAgo := currentTime - (i * 3) // 3 second block time from config

		reward := BASE_BLOCK_REWARD // Now int64, matches the struct field type
		activity = append(activity, ValidatorActivityItem{
			Type:      "block",
			Details:   fmt.Sprintf("Block #%d validated", blockNumber),
			Time:      formatTimeAgo(timeAgo),
			Timestamp: timeAgo,
			Reward:    &reward,
			TxHash:    fmt.Sprintf("block_%d_%s", blockNumber, address[:8]),
		})
	}

	return activity
}

// Helper function to get delegation activity
func (s *Server) getDelegationActivity(address string, validator *core.Validator) []ValidatorActivityItem {
	var activity []ValidatorActivityItem

	// Get recent delegation events from the validator's delegators
	for delegatorAddr, amount := range validator.Delegators {
		// Simulate recent delegation event
		activity = append(activity, ValidatorActivityItem{
			Type:      "delegation",
			Details:   fmt.Sprintf("New delegation: %s THR", formatToThrylos(amount)),
			Time:      formatTimeAgo(time.Now().Unix() - 3600), // 1 hour ago
			Timestamp: time.Now().Unix() - 3600,
			Amount:    &amount,
			From:      delegatorAddr,
			TxHash:    fmt.Sprintf("del_%s_%s", delegatorAddr[:8], address[:8]),
		})
	}

	return activity
}

// Helper function to get commission activity
func (s *Server) getCommissionActivity(address string, validator *core.Validator) []ValidatorActivityItem {
	var activity []ValidatorActivityItem

	// Calculate commission earnings based on delegated stake
	if validator.DelegatedStake > 0 {
		// Use actual validator reward rate from config: 9% APR
		validatorAPR := 0.09 // ValidatorRewardRate from config.go
		dailyReward := float64(validator.DelegatedStake) * validatorAPR / 365
		commissionEarning := int64(dailyReward * validator.Commission)

		if commissionEarning > 0 {
			activity = append(activity, ValidatorActivityItem{
				Type:      "commission",
				Details:   "Commission earned from delegations",
				Time:      formatTimeAgo(time.Now().Unix() - 7200), // 2 hours ago
				Timestamp: time.Now().Unix() - 7200,
				Reward:    &commissionEarning,
				TxHash:    fmt.Sprintf("comm_%s_%d", address[:8], time.Now().Unix()),
			})
		}
	}

	return activity
}

// Helper function to format amounts to THRYLOS
func formatToThrylos(nanoAmount int64) string {
	const NANO_PER_THRYLOS = 1000000000 // BaseUnit from config.go
	thrylos := float64(nanoAmount) / NANO_PER_THRYLOS
	return fmt.Sprintf("%.2f", thrylos)
}

// Helper function to format time ago
func formatTimeAgo(timestamp int64) string {
	diff := time.Now().Unix() - timestamp

	if diff < 60 {
		return fmt.Sprintf("%d seconds ago", diff)
	} else if diff < 3600 {
		minutes := diff / 60
		return fmt.Sprintf("%d minutes ago", minutes)
	} else if diff < 86400 {
		hours := diff / 3600
		return fmt.Sprintf("%d hours ago", hours)
	} else {
		days := diff / 86400
		return fmt.Sprintf("%d days ago", days)
	}
}

// Enhanced version that integrates with your transaction system
func (s *Server) getValidatorActivityEnhanced(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	address := vars["address"]

	limitStr := r.URL.Query().Get("limit")
	limit := 50
	if limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err == nil && parsedLimit > 0 && parsedLimit <= 1000 {
			limit = parsedLimit
		}
	}

	validator, err := s.worldState.GetValidator(address)
	if err != nil {
		s.writeError(w, "Validator not found", http.StatusNotFound)
		return
	}

	var activity []ValidatorActivityItem

	// 1. Check recent transactions for validator-related activity
	pendingTxs := s.worldState.GetPendingTransactions()
	for _, tx := range pendingTxs {
		if tx.To == address && (tx.Type == core.TransactionType_DELEGATE) {
			amount := tx.Amount
			activity = append(activity, ValidatorActivityItem{
				Type:      "delegation",
				Details:   fmt.Sprintf("New delegation: %s THR", formatToThrylos(tx.Amount)),
				Time:      formatTimeAgo(tx.Timestamp),
				Timestamp: tx.Timestamp,
				Amount:    &amount,
				From:      tx.From,
				TxHash:    tx.Hash,
			})
		}

		if tx.From == address && (tx.Type == core.TransactionType_UNDELEGATE) {
			amount := tx.Amount
			activity = append(activity, ValidatorActivityItem{
				Type:      "withdrawal",
				Details:   fmt.Sprintf("Undelegation processed: %s THR", formatToThrylos(tx.Amount)),
				Time:      formatTimeAgo(tx.Timestamp),
				Timestamp: tx.Timestamp,
				Amount:    &amount,
				TxHash:    tx.Hash,
			})
		}
	}

	// 2. Add block validation activity
	blockActivity := s.getBlockValidationActivity(address, validator)
	activity = append(activity, blockActivity...)

	// 3. Add commission activity
	commissionActivity := s.getCommissionActivity(address, validator)
	activity = append(activity, commissionActivity...)

	// Sort and limit
	sort.Slice(activity, func(i, j int) bool {
		return activity[i].Timestamp > activity[j].Timestamp
	})

	if len(activity) > limit {
		activity = activity[:limit]
	}

	response := ValidatorActivityResponse{
		Address:  address,
		Activity: activity,
		Count:    len(activity),
		Limit:    limit,
	}

	s.writeJSON(w, response)
}
